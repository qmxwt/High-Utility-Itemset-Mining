#ifndef _loader
#define _loader


#include<memory.h>


class Element
{
public:
  double nu;
  double nru;
  double npu;
  int    tid;
  int    ppos;  
};


class CUL
{
public:
  double   NU;
  double   NRU;
  double   CU;
  double   CRU;
  double   CPU;
  Element* list;
  int      len;
  int      name;
};


class Loader
{
  
public:
  CUL* cul;
  int  culnum;
  Loader(char* trans_file, char* price_file, double percent);
  ~Loader(void);

private:
  FILE* trans;
  FILE* price;

  int      item_order;   //twu-asc(-1), lexi(0), twu-desc(1)
  int      item_number;  //the number of items in db
  int      trans_number; //the number of transactions in db
  double*  ex_util;
  int*     item_freq;
  double*  item_twu;
  
  void scan_price_file(void);
  void scan_trans_file(double percent);
  void init_cul(void);
  void create_cul(void);

  char*    cache;
  long     cache_size;
  void     amplify_cache(void);
};


#endif
