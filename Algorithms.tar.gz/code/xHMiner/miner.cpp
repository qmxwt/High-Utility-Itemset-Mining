#include<glib.h>
#include"common.h"
#include"loader.h"
#include"miner.h"


extern double MINUTIL;
extern int EUCS_PRUNE;
extern GHashTable* EUCST;
long explored = 0; //explored itemsets


Miner::Miner( int len, char* outfp ) : IS( len, outfp )
{
   LAU = new double[ len ];
   CUTIL = new double[ len ];
   ey = new int[ len];
   valid = new int[ len ];
}


Miner::~Miner( void )
{
   delete []LAU;
   delete []CUTIL;
   delete []ey;
   delete []valid;
   printf("Search space : %ld\n", explored);
}


void Miner::Explore_Search_Tree( CUL* cul, int culnum )
{
   explored += culnum;
   for(int i=0; i<culnum; i++)
   {
      double utility = cul[i].NU + cul[i].CU;
      double remain = cul[i].NRU + cul[i].CRU;
      if( utility >= MINUTIL )
	IS.output( cul[i].name, utility );
      if( (utility + remain) >= MINUTIL )
      {
	 CUL* excul = NULL;
	 int  exculnum = 0;
	 excul = ConstructCUL( cul, culnum, i, exculnum );
	 if( exculnum != 0 )
	 {
	    IS.push( cul[i].name );
	    Explore_Search_Tree( excul, exculnum );
	    IS.pop( );
	 }
	 for(int j=0; j<exculnum; j++)
	   delete []excul[j].list;
	 delete []excul;
      }
   }
}


CUL*  Miner::ConstructCUL( CUL* cul, int culnum, int pos, int& exculnum )
{
   int extSz = 0;
   for( int i=pos+1; i<culnum; i++ )
   {
      double value = 0;
      if( EUCS_PRUNE )
      {
         int key[2] = { cul[pos].name, cul[i].name };
	 if( key[0] > key[1] )
	 {
	    key[0] = cul[i].name;
	    key[1] = cul[pos].name;
	 }
	 double* p = (double *)g_hash_table_lookup( EUCST, (gconstpointer)key );
	 if( p != NULL )  value = *p;
      }
     
      if( !( EUCS_PRUNE && value<MINUTIL ) )
      {
         valid[extSz] = i;
	 extSz++;
      }
   }

   double C1 = cul[pos].CU + cul[pos].CRU + cul[pos].NU + cul[pos].NRU;
   double C2 = cul[pos].CU + cul[pos].CRU;
   CUL* excul = new CUL[culnum-pos-1];
   excul = excul -  pos - 1 ; ////offset for faciliation
   for( int k=0; k<extSz; k++)
   {
      int i = valid[k];
      ey[i] = 0;
      LAU[i] = C1;
      CUTIL[i] = C2;
      excul[i].NU  = 0;
      excul[i].NRU = 0;
      excul[i].CU  = cul[pos].CU + cul[i].CU - cul[pos].CPU;
      excul[i].CRU = cul[i].CRU;
      excul[i].CPU = cul[pos].CU;
      int len = cul[pos].len < cul[i].len ? cul[pos].len : cul[i].len;
      excul[i].list = len > 0 ? new Element[len] : NULL;
      excul[i].len = 0;
      excul[i].name = cul[i].name;
   }


   doubArr da(extSz+1);
   GHashTable* HT = g_hash_table_new_full( g_str_hash, g_str_equal, g_free, g_free );
   for(int i=0; i<cul[pos].len; i++)
   {
      int tid = cul[pos].list[i].tid;
      da.init();
      for(int k=0; k<extSz; k++)
      {
	 int j = valid[k];
	 while( ey[j]<cul[j].len && tid>cul[j].list[ey[j]].tid )
	   ey[j]++;
	 if( ey[j]<cul[j].len && tid==cul[j].list[ey[j]].tid )
	 {
	    da.append( j , cul[j].list[ey[j]].nu );
	    CUTIL[j] = CUTIL[j] + cul[pos].list[i].nu + cul[pos].list[i].nru;
	 }
	 else
	 {  
	    LAU[j] = LAU[j] - cul[pos].list[i].nu - cul[pos].list[i].nru;
	    if( LAU[j] < MINUTIL )
	    {
	       delete []excul[j].list;
	       for(int a=k; a<extSz-1; a++)
		 valid[a] = valid[a+1];
	       extSz--;
	       k--;
	    }
	 }
      }
      
      if( da.len == 0 ) continue;
      if( da.len == extSz )
	Update_Closed( cul[pos].list[i], da, excul );
      else
      {
	 char* str = da.tostring( );
	 int* ele = (int *)g_hash_table_lookup( HT, (gpointer)str );
	 if( ele == NULL )
	 {
	    Insert_Element( cul[pos].list[i], da, excul );
	    char* str2 = (char *)g_malloc( strlen(str) + 1 );
	    int* v = (int *)g_malloc( sizeof(int) );
	    strcpy( str2, str );
	    *v = excul[da.t[da.len-1]].len - 1;
	    g_hash_table_insert( HT, (gpointer)str2, (gpointer)v );
	 }
	 else
	   Update_Element( cul[pos].list[i], da, excul, *ele );
      }
   }
   g_hash_table_destroy( HT );

   exculnum = extSz;
   int i = pos + 1;
   for( int k=0; k<extSz; k++)
   {
      int j = valid[k];
      if( CUTIL[j] < MINUTIL )
	{  delete []excul[j].list;  exculnum--;  }
      else
	{  excul[i] = excul[j];     i++;      }
   }
   excul = excul + pos + 1 ; ////offset again
   return excul;
}


void Miner::Update_Closed( Element& prefix, doubArr& da, CUL* excul )
{
   double nru = 0;
   for( int i=da.len-1;  i>=0;  i-- )
   {
      int k = da.t[i];
      double u = da.u[i];
      excul[k].CU = excul[k].CU + prefix.nu + u - prefix.npu;
      excul[k].CRU = excul[k].CRU + nru;
      excul[k].CPU = excul[k].CPU + prefix.nu;
      nru = nru + u - prefix.npu;
   }
}


void Miner::Insert_Element( Element& prefix, doubArr& da, CUL* excul )
{
   Element* last = NULL;
   double nru = 0;
   for( int i=da.len-1;  i>=0;  i-- )
   {
      int k = da.t[i];
      double u = da.u[i];
      Element& cur = excul[k].list[excul[k].len];
      cur.nu = prefix.nu + u - prefix.npu;
      cur.nru = nru;
      cur.npu = prefix.nu;
      cur.tid = prefix.tid;
      if( last != NULL ) last->ppos = excul[k].len;
      last = &cur;
      nru = nru + u - prefix.npu;
      excul[k].NU = excul[k].NU + cur.nu;
      excul[k].NRU = excul[k].NRU + cur.nru;
      excul[k].len++;
   }
   last->ppos = - 1;
}


void Miner::Update_Element( Element& prefix, doubArr& da, CUL* excul, int ppos )
{
   double nru = 0;
   for( int i=da.len-1;  i>=0;  i-- )
   {
      int k = da.t[i];
      double u = da.u[i];
      Element& cur = excul[k].list[ppos];
      cur.nu += ( prefix.nu + u - prefix.npu );
      cur.nru += nru;
      cur.npu += prefix.nu;
      ppos = cur.ppos;
      excul[k].NU = excul[k].NU + ( prefix.nu + u - prefix.npu );
      excul[k].NRU = excul[k].NRU + nru;
      nru = nru + u - prefix.npu;
   }
}
