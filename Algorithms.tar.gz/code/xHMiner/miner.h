#ifndef _miner
#define _miner


#include"common.h"
#include"loader.h"

class Miner
{
public:
  Miner( int len, char* outfp );
  ~Miner( void );
  void Explore_Search_Tree( CUL* cul, int culnum );
  itemSet IS;

private:
  double*   LAU;
  double*   CUTIL;
  int*      ey;
  int*      valid;

  CUL*  ConstructCUL( CUL* cul, int culnum, int pos, int& exculnum );
  void  Update_Closed( Element& prefix, doubArr& da, CUL* excul );
  void  Insert_Element( Element& prefix, doubArr& da, CUL* excul );
  void  Update_Element( Element& prefix, doubArr& da, CUL* excul, int ppos );
};

#endif
