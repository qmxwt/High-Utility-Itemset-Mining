#ifndef _loader
#define _loader


#include<memory.h>
#include"common.h"


class Node
{
public:
  double util;
  double extu;
  int    itemname;
  int    len;
  int*   end;  //points to the end of a transaction
  int*   pos;  //points to the item in the transaction
};


class Iudata
{
public:
  int   num;
  Node* list;
  Iudata( int n ) : num(n)
  {  list = new Node[n];  }
  ~Iudata( void )
  {  delete []list;  }
};


class Dataset
{
public:
  int     trannum;
  int     memsize;
  int*    items;
  double* utils;
  int*    index;
  double* preutil;
  int     mempos;
  Dataset( int freq_num, int tran_num );
  ~Dataset( void );
  void reset( void );
  void appele( int i, double u );
  void apptran( twosomeTable& t, double twu, double pu );
  void sortds( void );
  void merge( void ); //run after sortds
private:
  void  sortds( int pos, int low, int high );
};


class DB
{
public:
  int len;
  int* item;
  double* util;
  DB( int n ) : len(n)
  {
     item = new int[n];
     util = new double[n];
  }
  ~DB( void )
  {
     delete []item;
     delete []util;
  }
};


class Loader
{
public:
  DB*      db;
  Iudata*  iu;
  Loader( char* trans_file, char* price_file, double percent );
  ~Loader( void );

private:
  FILE* trans;
  FILE* price;

  int     tran_number; //the number of transactions
  int     item_order;  //twu-asc(-1), lexical(0), twu-desc(1)
  int     item_number; //the number of items in db
  int*    item_freq;
  double* item_twu;
  double* ex_util;

  void scan_price_file( void );
  void scan_trans_file( double percent );
  void init_struct( void );
  void create_struct( void );

  char* cache;
  long  cache_size;
  void  amplify_cache(void);
};


void print_db( DB* db );
void print_iu( Iudata* iu );

#endif
