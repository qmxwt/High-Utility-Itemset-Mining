#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include"common.h"
#include"loader.h"


extern double MINUTIL;
Dataset* DS = NULL;


//////////////////////////// class Dataset/////////////////////////////////
///////////////////////////////////////////////////////////////////////////
Dataset::Dataset( int freq_num, int tran_num )
{
   memsize = freq_num + tran_num + 1; //having an end
   items = new int[ memsize ];
   utils = new double[ memsize ];
   index = new int[ tran_num ];
   preutil = new double[ tran_num ];
   trannum = 0;  //Empty trans would not be saved
   mempos = 0;
}


Dataset::~Dataset( void )
{
   delete []items;
   delete []utils;
   delete []index;
   delete []preutil;
}


void Dataset::reset( void )
{
   trannum = 0;
   mempos = 0;
}


void Dataset::appele( int i, double u )
{
   items[mempos] = i;
   utils[mempos] = u;
   if( i == - 1)
     index[trannum++] = mempos; //++
   mempos++;
}


//Assure t is not null and is sorted
void Dataset::apptran( twosomeTable& t, double twu, double pu )
{
   index[trannum] = mempos;
   preutil[trannum++] = pu; //++
   items[mempos] = - t.usedLen; 
   utils[mempos++] = twu;   //++
   for( int i=0; i<t.usedLen; i++,mempos++ )
   {
      items[mempos] = t.table[i].name;
      utils[mempos] = t.table[i].value;
   }
   items[mempos] = - 1;
}


void Dataset::sortds( void )
{
   if( trannum > 1 )
     sortds( 1, 0, trannum-1 );
}


void Dataset::sortds( int pos, int low, int high )
{
   int object = items[ index[low] - items[index[low]] - pos ];
   int lt = low;
   int gt = high;
   int cur = low + 1;

   while( cur <= gt )
     if( items[ index[cur] - items[index[cur]] - pos ] < object )
     {
        int temp = index[cur];
	index[cur] = index[lt];
	index[lt] = temp;
	double tempd = preutil[cur];
	preutil[cur] = preutil[lt];
	preutil[lt] = tempd;
	lt++;
	cur++;
     }
     else
       if( items[ index[cur] - items[index[cur]] - pos ] == object )
	 cur++;
       else
       {
	  while( cur <= gt && items[ index[gt] - items[index[gt]] - pos ] > object )
	    gt--;
	  if( cur < gt )
	  {
	     int temp = index[cur];
	     index[cur] = index[gt];
	     index[gt] = temp;
	     double tempd = preutil[cur];
	     preutil[cur] = preutil[gt];
	     preutil[gt] = tempd;
	     gt--;
	  }	    
       }

   while( low <= high && items[ index[low] - items[index[low]] - pos ] < 0 ) low++;
   if( low < lt - 1 )
     sortds(  pos, low, lt-1 );
   if( lt < gt && items[ index[lt] - items[index[lt]] - pos ] >= 0 )
     sortds( pos+1, lt, gt );
   if( gt + 1 < high )
     sortds( pos, gt+1, high );
}


void Dataset::merge( void )
{
   for(int i=trannum-1; i>0; i--)
     if( items[index[i]] == items[index[i-1]] )
     {
        int cur = index[i] + 1;
	int pre = index[i-1] + 1;
	while( items[cur] >= 0 && items[cur] == items[pre] )
	  {  cur++, pre++;  }
	if( items[cur] < 0 && items[pre] < 0 )
	{
	   int last = cur;
	   cur = index[i];
	   pre = index[i-1];
	   for( ; cur<last; cur++, pre++ )
	     utils[pre] += utils[cur];
	   index[i] = - 1;
	   preutil[i-1] += preutil[i];
	}
     }

   int num = 0;
   for(int i=0; i<trannum; i++)
     if( index[i] != - 1 )
       index[num++] = index[i];
   trannum = num;
}
///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////




//////////////////////////// class Loader /////////////////////////////////
///////////////////////////////////////////////////////////////////////////
Loader::Loader(char* trans_file, char* price_file, double percent)
  : db(NULL), iu(NULL)
{
   trans = fopen( trans_file, "rt" );
   if( trans == NULL )
   {
      printf("Transaction file cannot open!\n");
      exit(0);
   }
   price = fopen( price_file, "rt" );
   if( price == NULL )
   {
      printf("Price file cannot open!\n");
      fclose( trans );
      exit(0);
   }

   scan_price_file( );
   //item_* and cache are allocated, ex_util is assigned
   scan_trans_file( percent );
   //variables item_*, trans_number  and MINUTIL are assigned
   //item_order = 1;  //Remember Change!
   init_struct( );
   create_struct( );
   //mat is constructed

   delete []ex_util;
   delete []item_freq;
   delete []item_twu;
   delete []cache;
   fclose( trans );
   fclose( price );
}


Loader::~Loader( void )
{
   delete db;
   for( int i=0; i<iu->num; i++ )
   {
      delete []iu->list[i].end;
      delete []iu->list[i].pos;
   }
   delete iu;
   delete DS;
}


void Loader::scan_price_file(void)
{
   fseek( price, 0, SEEK_END );
   long ch_num = ftell( price );
   cache = new char[ ch_num ];
   cache_size = ch_num;
   fseek( price, 0, SEEK_SET );
   fread( cache, ch_num, 1, price );

   item_number = 0;
   long i = 0;
   for( ; i<ch_num; i++ )
     if( cache[i]=='\n' )
       item_number++;

   ex_util = new double[ item_number ];
   int j = 0;
   double temp;

   i = 0;
   while( i<ch_num )
   {
      temp = 0;
      while( cache[i]>='0' && cache[i]<='9' )
        temp = temp * 10 + (double)(cache[i++] - '0'); //i++
      if( cache[i]=='.' )
      {
	 i++;  //skip '.'
	 double reduce = (double)0.1;
	 while( cache[i]>='0' && cache[i]<='9' )
	 {
	    temp += (double)(cache[i++] - '0') * reduce ;  //i++
	    reduce *= (double)0.1;
	 }
      }
      i++;  //skip '\n'
      ex_util[j++] = temp;  //j++
   }

   item_freq = new int[ item_number ];
   memset( item_freq, 0, item_number*sizeof(int) );
   item_twu = new double[ item_number ];
   memset( item_twu, 0, item_number*sizeof(double) );
}


void Loader::amplify_cache(void) //add 64k
{
   long len = cache_size + 64 * 1024;
   char* temp =new char[len];
   memcpy(temp, cache, cache_size);
   delete []cache;
   cache = temp;
   cache_size = len;
}


void Loader::scan_trans_file(double percent)
{
   double total_util = 0;
   int* items = new int[item_number];
   int top;

   tran_number = 0;
   long ch_num;
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans ); //!!return count
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	      amplify_cache();
	 }while( c!='\n' );
      }

      long i = 0;
      int item;
      int quantity;
      double trans_util;
      while( i<ch_num )
      {
	 trans_util = 0;
	 top = 0;
	 while( 1 )
	 {
	    item = quantity = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + (int)( cache[i++] - '0' );  //i++
	    items[top++] = item;  //top++
	    i++;  //skip ' '
	    while( cache[i]>='0' && cache[i]<='9' )
	      quantity = quantity * 10 + (int)( cache[i++] - '0' );  //i++
	    trans_util += ( ex_util[item] * (double)quantity );
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break;  }  //skip '\n'
	 }////get a transaction
	 for(int j=0; j<top; j++ )
	 {
	    item_freq[ items[j] ] ++;
	    item_twu[ items[j] ] += trans_util;
	 }
	 total_util += trans_util;
	 tran_number++; 
      }
   }while( !feof(trans) );

   delete []items;
   MINUTIL = total_util * percent ;
}


void Loader::init_struct( void )
{
   twosomeTable t(item_number);
   double sumlen = 0;
   int total = 0;
   int i = 0;
   for( ; i<item_number; i++ )
   {
      sumlen += item_freq[i];
      if( item_twu[i] >= MINUTIL )
      {
         t.append_twosome( i, item_twu[i] );
	 total += item_freq[i];
      }
      else
	item_freq[i] = - 1;
   }

   double density = ((double)sumlen) / ((double)tran_number);
   density = density / ((double)item_number);
   if( density < 0.01 )
     DS = NULL;
   else
     DS = new Dataset( total, tran_number );
   
   db = new DB( total );
   iu = new Iudata( t.usedLen );
   t.ascending_sort( );

   db->len = 0;
   for( i=0; i<t.usedLen; i++ )
   {
      iu->list[i].util = 0;
      iu->list[i].extu = 0;
      iu->list[i].itemname = t.table[i].name;
      iu->list[i].len = 0;
      iu->list[i].end = new int[ item_freq[t.table[i].name] ];
      iu->list[i].pos = new int[ item_freq[t.table[i].name] ];
      item_freq[t.table[i].name] = i;
   }
}


void Loader::create_struct(void)
{
   twosomeTable t(item_number);
   long ch_num;
   fseek( trans, 0, SEEK_SET );
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans );
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	       amplify_cache();
	 }while( c!='\n' );
      }

      int i = 0;
      int item;
      int quantity;
      while( i<ch_num )
      {
	 double ubutil = 0;
	 t.init( );
	 while( 1 )
	 {
	    item = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + int( cache[i++] - '0' );  //i++
	    i++;  //skip ' '
	    if( item_freq[item]>=0 )
	    {
	       quantity = 0;
	       while( cache[i]>='0' && cache[i]<='9' )
		 quantity = quantity * 10 + int( cache[i++] - '0' );  //i++
	       double utility = ex_util[item] * quantity;
	       t.append_twosome( item_freq[item], utility );
	       ubutil += utility;
	    }
	    else
	      while( cache[i]>='0' && cache[i]<='9' ) i++;
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break; }  //skip '\n'
	 }////get a transaction
	 if( t.usedLen != 0 )
	 {
	    t.sort( );
	    if( DS != NULL )
	      DS->apptran( t, ubutil, 0 );
	    else
	    {
	       int transend = db->len + t.usedLen - 1;
	       int j = 0;
	       for( ; j<t.usedLen-1; j++)
	       {
		  int item = t.table[j].name;
		  db->item[db->len] = t.table[j].name;
		  db->util[db->len] = t.table[j].value; 
		  iu->list[item].util += t.table[j].value;
		  iu->list[item].extu += ubutil;
		  ubutil -= t.table[j].value;
		  iu->list[item].end[iu->list[item].len] = transend;
		  iu->list[item].pos[iu->list[item].len] = db->len++; //++
		  iu->list[item].len++;
	       }
	       int item = t.table[j].name;
	       db->item[db->len] = t.table[j].name;
	       db->util[db->len++] = t.table[j].value;  //++
	       iu->list[item].util += t.table[j].value;
	    }
	 }
      }
   }while( !feof(trans) );

   if( DS != NULL )
   {
      DS->sortds( );
      DS->merge( );
      for( int i=0; i<DS->trannum; i++ )
      {
	 int pos = DS->index[i];
	 int transend = db->len - DS->items[pos] - 1;
	 double ubutil = DS->utils[pos];
	 for( pos++; DS->items[pos+1]>=0; pos++ )
	 {
	    int item = DS->items[pos];
	    db->item[db->len] = DS->items[pos];
	    db->util[db->len] = DS->utils[pos];
	    iu->list[item].util += DS->utils[pos];
	    iu->list[item].extu += ubutil;
	    ubutil -= DS->utils[pos];
	    iu->list[item].end[iu->list[item].len] = transend;
	    iu->list[item].pos[iu->list[item].len] = db->len++;
	    iu->list[item].len++;
	 }
	 int item = DS->items[pos];
	 db->item[db->len] = DS->items[pos];
	 db->util[db->len++] = DS->utils[pos];
	 iu->list[item].util += DS->utils[pos];
      }
   }
}
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////


void print_db( DB* db )
{
   printf("DB.........................................................\n");
   for(int i=0; i<db->len; i++)
   {
      if( i!=0 && i%5 == 0 )
	printf("\n");
      printf( "(%d,%lf) ", db->item[i], db->util[i] );
   }
   printf("...........................................................\n");
}


void print_iu( Iudata* iu )
{
   printf("Iu.........................................................\n");
   for( int i=0; i<iu->num; i++ )
   {
      printf( "util : %lf\n", iu->list[i].util );
      printf( "extu : %lf\n", iu->list[i].extu );
      printf( "name : %d\n", iu->list[i].itemname );
      for( int j=0; j<iu->list[i].len; j++ )
	printf("[%d,%d] ", iu->list[i].end[j], iu->list[i].pos[j]);
      printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
   }
   printf("...........................................................\n");
}
