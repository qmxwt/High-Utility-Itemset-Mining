#include<stdio.h>
#include<memory.h>
#include"common.h"
#include"loader.h"
#include"miner.h"


extern double MINUTIL;
long explored = 0; //explored itemsets


//////////////////////////////////////////class Projection////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

Projection::Projection( int le, int nu )
{
   len = le;
   preutil = new double[len];
   pos = new int[len];
   pos[0] = 0; //points to a null trans in TB
   cur = 1;    //start from 1
   pri = new int[nu];
   sec = new int[nu];
   pnum = 0;
   snum = 0;
}


Projection::~Projection( void )
{
   delete []preutil;
   delete []pos;
   delete []pri;
   delete []sec;
}


void Projection::show( void )
{
   printf("--------------------------  Projection -----------------------\n");
   printf("Primary : ");
   for(int i=0; i<pnum; i++)
     printf("%d ", pri[i]);
   printf("\n");
   printf("Secondary : ");
   for(int i=0; i<snum; i++)
     printf("%d ", sec[i]);
   printf("\n");
   printf("List : \n");
   for(int i=0; i<cur; i++)
     printf("[%lf %d] ", preutil[i], pos[i]);
   printf("\n");
   printf("--------------------------------------------------------------\n");
}
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////class Miner/////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

Miner::Miner( Dataset& ds, Tbuffer& tb, itemSet& is, int len )
  : DS(ds), TB(tb), IS(is)
{
   lu = new double[ len ];
   su = new double[ len ];
   mapp = new int[ len ];
   memset( mapp, 0, len * sizeof(int) );
}


Miner::~Miner( void )
{
   delete []lu;
   delete []su;
   delete []mapp;
   printf("Search space : %ld\n", explored);
}


void Miner::mine( void )
{
   Projection* pdb = new Projection( DS.trannum + 1, DS.itemnum );
   for(int i=0; i<DS.trannum; i++)
   {  
      pdb->preutil[pdb->cur] = 0;
      pdb->pos[pdb->cur++] = DS.index[i] + 1; //++
   }
   for(int i=0; i<DS.itemnum; i++)
   {
      if( DS.support[i] > 0 )
	pdb->pri[pdb->pnum++] = i;  //++
      pdb->sec[pdb->snum++] = i;    //++
   }
   explored += ( pdb->snum - pdb->pnum );  //note! these are explored but are not expanded
   search( 1, *pdb);
   delete pdb;
}


void Miner::search( int level, Projection& pdb )
{
   explored += pdb.pnum;
   for(int i=0; i<pdb.snum; i++)
     mapp[pdb.sec[i]]++;
   int max = pdb.pnum > pdb.snum ? pdb.pnum : pdb.snum;
   Projection* sub = new Projection( pdb.cur, max );

   int cursor = 0;
   for( int i=0; i<pdb.pnum; i++ )
   {
      int upbound = TB.pos;
      sub->cur = 1;
      double utility = create_projection( level, pdb, i, *sub, upbound );
      if( utility >= MINUTIL )
	IS.output( DS.itemname[pdb.pri[i]], utility );
      if( sub->cur > 1 )
      {
	 calculate_lu_su( cursor, level, pdb, i, *sub );
	 if( sub->pnum > 0 )
	 {
	    IS.push( DS.itemname[pdb.pri[i]] );
	    search( level+1, *sub  );
	    IS.pop( );
	 }
      }
      TB.pos = upbound; //purge generated trans
   }
   
   delete sub;
   for(int i=0; i<pdb.snum; i++)
     mapp[pdb.sec[i]]--;
}
 

double Miner::create_projection( int level, Projection& pdb, int no, Projection& sub, int upbound )
{
   int item = pdb.pri[no];
   double utility = 0;
   for( int i=1; i<pdb.cur; i++ )
   {
      int dist = 0;
      int* curi = (pdb.pos[i]>0) ? (DS.items+pdb.pos[i]) : (TB.items-pdb.pos[i]);
      double* curu = (pdb.pos[i]>0) ? (DS.utils+pdb.pos[i]) : (TB.utils-pdb.pos[i]);
      while( curi[dist] >= 0 && curi[dist] < item )
	dist++;
      if( curi[dist] == item )
      {
	 double prefixu = pdb.preutil[i] + curu[dist];
	 utility += ( pdb.preutil[i] + curu[dist] );
	 dist++; //skip the item
	 while( curi[dist] >= 0 && mapp[curi[dist]] != level )
	   dist++;
	 if( curi[dist] >= 0 ) //in this case, mapp[curi[dist]] == level 
	 {
	    int anchor = dist;
	    int off = 0;
	    int* prei=(sub.pos[sub.cur-1]>0) ? (DS.items+sub.pos[sub.cur-1]) : (TB.items-sub.pos[sub.cur-1]);
	    double* preu=(sub.pos[sub.cur-1]>0) ? (DS.utils+sub.pos[sub.cur-1]) : (TB.utils-sub.pos[sub.cur-1]);
	    while( curi[dist] == prei[off] )
	    {
	       for( dist++; curi[dist]>=0 && mapp[curi[dist]]!=level; dist++ );
	       for( off++; prei[off]>=0 && mapp[prei[off]]!=level; off++ );
	       if( curi[dist]<0 || prei[off]<0 )
		 break;
	    }
	    if( curi[dist]<0 && prei[off]<0 ) //identical trans
	    {
	       dist = anchor;
	       off = 0;
	       if( sub.pos[sub.cur-1] <= - upbound ) //merge 
	       {
		  sub.preutil[sub.cur-1] += prefixu;
		  for( ; curi[dist]>=0; dist++ )
		    if( mapp[curi[dist]] == level )
		    {  
		       while( mapp[prei[off]] != level ) off++;
		       preu[off++] += curu[dist]; //++
		    }
	       }
	       else  //generate
	       {
		  sub.cur--;
		  sub.pos[sub.cur] = - TB.pos;
		  sub.preutil[sub.cur] += prefixu;
		  for( ; curi[dist]>=0; dist++ )
		    if( mapp[curi[dist]] == level )
		    {
		       while( mapp[prei[off]] != level ) off++;
		       TB.append( curi[dist], curu[dist]+preu[off] );
		       off++;
		    }
		  TB.append( - 1, 0 );
		  sub.cur++;
	       }
	    }
	    else //different trans
	    {
	       if( pdb.pos[i] > 0 )
		 sub.pos[sub.cur] = pdb.pos[i] + anchor;
	       else
		 sub.pos[sub.cur] = pdb.pos[i] - anchor;
	       sub.preutil[sub.cur] = prefixu;
	       sub.cur++;
	    } //if( curi[dist]<0 && prei[off]<0 ) //identical trans
	 }//if( curi[dist] >= 0 ) //mapp[curi[dist]] == level in this case
      }//if( curi[dist] == item )
   }//for( int i=1; i<pdb.cur; i++ )
   return utility;
}


void Miner::calculate_lu_su( int& cursor, int level, Projection& pdb, int no, Projection& sub )
{
   while( cursor<pdb.snum && pdb.sec[cursor]<=pdb.pri[no] )
     cursor++;
   for( int i=cursor; i<pdb.snum; i++ )
     lu[pdb.sec[i]] = su[pdb.sec[i]] = 0;

   for(int i=1; i<sub.cur; i++)
   {
      double local = sub.preutil[i];
      int* items = (sub.pos[i]>0) ? (DS.items+sub.pos[i]) : (TB.items-sub.pos[i]);
      double* utils = (sub.pos[i]>0) ? (DS.utils+sub.pos[i]) : (TB.utils-sub.pos[i]);
      int dist = 0;
      for(  ; items[dist]>=0; dist++ )
	if( mapp[items[dist]] == level )
	  local += utils[dist];
      double subtree = local;
      dist = 0;
      while( items[dist] >= 0 && mapp[items[dist]] != level )
	dist++;
      if( items[dist] >= 0 )
      {
	 su[items[dist]] += subtree;
	 subtree -= utils[dist];
	 for(dist++; items[dist]>=0; dist++ )
	   if( mapp[items[dist]] == level )
	   {
	      lu[items[dist]] += local;
	      su[items[dist]] += subtree;
	      subtree -= utils[dist];
	   }
      }
   }

   sub.pnum = sub.snum = 0;
   for( int i=cursor; i<pdb.snum; i++ )
   {
      if( lu[pdb.sec[i]] >= MINUTIL )
	sub.sec[sub.snum++] = pdb.sec[i];
      if( su[pdb.sec[i]] >= MINUTIL )
	sub.pri[sub.pnum++] = pdb.sec[i];
   }  
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
