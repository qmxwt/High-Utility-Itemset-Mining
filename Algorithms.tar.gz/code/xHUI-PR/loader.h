#ifndef _loader
#define _loader


#include<memory.h>
#include"common.h"


class Dataset
{
public:
  int     trannum;
  int     memsize;
  int*    items;
  double* utils;
  int*    index;
  double* preutil;
  int     mempos;
  int     itemnum;
  int*    support;
  int*    itemname;
  Dataset( int freq_num, int tran_num, int item_num );
  ~Dataset( void );
  void apptran( twosomeTable& t, double twu, double pu );
  void sortds( void );
  void merge( void ); //run after sortds
  void show( void );
private:
  void  sortds( int pos, int low, int high );
};


class Tbuffer
{
public:
  int*    items;
  double* utils;
  int     size;
  int     pos;
  Tbuffer( void );
  ~Tbuffer( void );
  void append( int i, double u );
  void show( void );
};


class Loader
{
public:
  Dataset* DS;
  Tbuffer* TB;
  Loader( char* trans_file, char* price_file, double percent );
  ~Loader( void );

private:
  FILE* trans;
  FILE* price;

  int     tran_number; //the number of transactions
  int     item_order;  //twu-asc(-1), lexical(0), twu-desc(1)
  int     item_number; //the number of items in db
  int*    item_freq;
  double* item_twu;
  double* ex_util;

  void scan_price_file( void );
  void scan_trans_file( double percent );
  void init_struct( void );
  void create_struct( void );

  char* cache;
  long  cache_size;
  void  amplify_cache(void);
};


#endif
