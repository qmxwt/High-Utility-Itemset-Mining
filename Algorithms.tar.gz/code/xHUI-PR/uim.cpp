#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include"common.h"
#include"loader.h"
#include"miner.h"


extern long peak;


int main(int argc, char* argv[])
{
   struct timeval t1, t2;
   long double interval;
   gettimeofday(&t1, NULL);
   if( argc!=4 && argc!=5 )
   {
      printf("Usage :\n");
      printf("  HUI-PR  trans_file  price_file  min_util  [output_filename]\n");
      exit(0);
   }
   Loader L( argv[1], argv[2], (double)(atof(argv[3])) );
   char* outfp = NULL;
   if( argc==5 )  outfp = argv[4];
   itemSet IS( L.DS->itemnum, outfp );
   Miner M( *L.DS, *L.TB, IS, L.DS->itemnum );
   M.mine( );
   IS.show();
   
   gettimeofday(&t2, NULL);
   interval = ((t2.tv_sec - t1.tv_sec) * 1000) + ((t2.tv_usec - t1.tv_usec) / 1000);
   interval = interval / 1000;
   printf("Mining time (second) : %Lf\n", interval);
   long double memusage = peak / (long double) (1024 * 1024 );
   printf("Peak memory (MB) : %Lf\n", memusage);
  
   return 0;
}
