#include<stdio.h>
#include<stdlib.h>
#include"common.h"
#include"loader.h"


extern double MINUTIL;
extern int ITERDEPTH;


Loader::Loader(char* trans_file, char* price_file, double percent)
  :  caul(NULL)
{
   trans = fopen( trans_file, "rt" );
   if( trans==NULL )
   {
      printf("Transaction file cannot open!\n");
      exit(0);
   }
   price = fopen( price_file, "rt" );
   if( price==NULL )
   {
      printf("Price file cannot open!\n");
      fclose( trans );
      exit(0);
   }

   scan_price_file( );
   //item_* and cache are allocated, ex_util is assigned
   scan_trans_file( percent );
   //variables item_*, trans_number and MINUTIL are assigned

   item_order = 1;
   init_caul( );
   create_caul( );
   //caul is constructed

   delete []ex_util;
   delete []item_freq;
   delete []item_twu;
   delete []cache;
   fclose( trans );
   fclose( price );
}


Loader::~Loader(void)
{
   delete caul;
}


void Loader::scan_price_file(void)
{
   fseek( price, 0, SEEK_END );
   long ch_num = ftell( price );
   cache = new char[ ch_num ];
   cache_size = ch_num;
   fseek( price, 0, SEEK_SET );
   fread( cache, ch_num, 1, price );

   item_number = 0;
   long i = 0;
   for( ; i<ch_num; i++ )
     if( cache[i]=='\n' )
       item_number++;

   ex_util = new double[ item_number ];
   int j = 0;
   double temp;

   i = 0;
   while( i<ch_num )
   {
      temp = 0;
      while( cache[i]>='0' && cache[i]<='9' )
        temp = temp * 10 + (double)(cache[i++] - '0'); //i++
      if( cache[i]=='.' )
      {
	 i++;  //skip '.'
	 double reduce = (double)0.1;
	 while( cache[i]>='0' && cache[i]<='9' )
	 {
	    temp += (double)(cache[i++] - '0') * reduce ;  //i++
	    reduce *= (double)0.1;
	 }
      }
      i++;  //skip '\n'
      ex_util[j++] = temp;  //j++
   }

   item_freq = new int[ item_number ];
   memset( item_freq, 0, item_number*sizeof(int) );
   item_twu = new double[ item_number ];
   memset( item_twu, 0, item_number*sizeof(double) );
}


void Loader::amplify_cache(void) //add 64k
{
   long len = cache_size + 64 * 1024;
   char* temp =new char[len];
   memcpy(temp, cache, cache_size);
   delete []cache;
   cache = temp;
   cache_size = len;
}


void Loader::scan_trans_file(double percent)
{
   trans_number = 0;
   double total_util = 0;
   int* items = new int[item_number];
   int top;

   long ch_num;
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans ); //!!return count
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	      amplify_cache();
	 }while( c!='\n' );
      }

      long i = 0;
      int item;
      int quantity;
      double trans_util;
      while( i<ch_num )
      {
	 trans_util = 0;
	 top = 0;
	 while( 1 )
	 {
	    item = quantity = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + (int)( cache[i++] - '0' );  //i++
	    items[top++] = item;  //top++
	    i++;  //skip ' '
	    while( cache[i]>='0' && cache[i]<='9' )
	      quantity = quantity * 10 + (int)( cache[i++] - '0' );  //i++
	    trans_util += ( ex_util[item] * (double)quantity );
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break;  }  //skip '\n'
	 }////get a transaction
	 trans_number++;
	 for(int j=0; j<top; j++ )
	 {
	    item_freq[ items[j] ] ++;
	    item_twu[ items[j] ] += trans_util;
	 }
	 total_util += trans_util;
      }
   }while( !feof(trans) );

   delete []items;
   MINUTIL = total_util * percent ;
}


void Loader::init_caul(void)
{
   twosomeTable t(item_number);
   int freq = 0;
   int i = 0;
   for( ; i<item_number; i++ )
     if( item_twu[i]>=MINUTIL )
     {
        freq += item_freq[i];
        t.append_twosome( i, item_twu[i] );
     }
     else
       item_freq[i] = - 1;
   ITERDEPTH = t.usedLen + 1;
   caul = new CAUL( freq, trans_number, t.usedLen );

   switch( item_order )
   {
      case  -1  :  t.ascending_sort();   break;
      case   0  :  t.sort();   break;
      case   1  :  t.descending_sort();  break;
   }
   for( i=0; i<t.usedLen; i++ )
   {
      caul->itemname[i] = t.table[i].name;
      caul->table[i].uBfpe = caul->table[i].uBitem\
	= caul->table[i].utility = caul->table[i].support = 0;
      caul->table[i].next = - 1;
      item_freq[t.table[i].name] = i;
   }
}


void Loader::sort_element(int low, int high)
{
   int i = low;
   int j = high;
   key = caul->dbase[i];
   int item = key.item;

   while( i!=j )
   {
      while( i<j && item < caul->dbase[j].item )
        j--;
      if( i<j )
        caul->dbase[i++] = caul->dbase[j];
      while( i<j && caul->dbase[i].item < item )
        i++;
      if( i<j )
        caul->dbase[j--] = caul->dbase[i];
   }
   caul->dbase[i] = key;
   if( low < (i-1) )   sort_element( low, i-1 );
   if( (i+1) < high )  sort_element( i+1, high );
}


void Loader::create_caul(void)
{
   long ch_num;
   int max_trans_len = 0;

   caul->dbase[0].item = - 1;
   caul->dbase[0].utility = 0;
   int lastele = 1;
   fseek( trans, 0, SEEK_SET );
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans );
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	       amplify_cache();
	 }while( c!='\n' );
      }

      int i = 0;
      int item;
      int quantity;
      while( i<ch_num )
      {
	 double twu = 0;
	 int firstele = lastele;
	 while( 1 )
	 {
	    item = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + int( cache[i++] - '0' );  //i++
	    i++;  //skip ' '
	    if( item_freq[item]>=0 )
	    {
	       quantity = 0;
	       while( cache[i]>='0' && cache[i]<='9' )
		 quantity = quantity * 10 + int( cache[i++] - '0' );  //i++
	       caul->dbase[lastele].item = item_freq[item];
	       caul->dbase[lastele].utility = ex_util[item] * quantity;
	       caul->dbase[lastele].preutil = caul->dbase[lastele].utility;
	       twu += caul->dbase[lastele].utility;
	       lastele++;
	    }
	    else
	      while( cache[i]>='0' && cache[i]<='9' ) i++;
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break; }  //skip '\n'
	 }////get a transaction
	 if( firstele==lastele )
	   continue;
	 ////the transaction is invalid
	 caul->transnum++; 
	 int tail = lastele - 1;
	 int translen = lastele - firstele;
	 if( translen >= 2 ) 
	   sort_element( firstele, tail );
	 if( translen > max_trans_len )
	   max_trans_len = translen;

	 double fpe = 0;
	 for(int j=firstele; j<=tail; j++)
	 {
	    int item = caul->dbase[j].item;
	    fpe += caul->dbase[j].utility;
	    caul->table[item].support ++;
	    caul->table[item].utility += caul->dbase[j].utility;
	    caul->table[item].uBitem  += twu;
	    caul->table[item].uBfpe += fpe;
	    caul->dbase[j].next = caul->table[item].next;
	    caul->table[item].next = j;
	 }
	 caul->dbase[lastele].item = - 1;
	 caul->dbase[lastele].utility = 0;
	 ////set the extra element
	 lastele++;  
      }
   }while( !feof(trans) );


   if ( ITERDEPTH > max_trans_len )
     ITERDEPTH = max_trans_len + 1;

   caul->dblen = lastele;
}


//*
void Loader::show_caul(void)
{
   Entry* t = caul->table;
   printf("item_num : %d\n", caul->itemnum);
   printf("Table :\tsupport\t\tutility\t\tuBitem\t\tuBfpe\t\tnext\n");
   for(int i=0; i<caul->itemnum; i++)
   {
      printf("       \t");
      printf("%d\t",  t[i].support);
      printf("%lf\t", t[i].utility);
      printf("%lf\t", t[i].uBitem);
      printf("%lf\t", t[i].uBfpe);
      printf("%d\n",  t[i].next);
   }

   printf("Transaction: \n");
   for(int i=0; i<caul->dblen; i++ )
   {
      printf("%d : ",  i);
      printf("%d   ",  caul->dbase[i].item);
      printf("%lf   ", caul->dbase[i].utility);
      printf("%d   \n",  caul->dbase[i].next);     
   }
}
//*/
