#ifndef _miner
#define _miner


#include"common.h"
#include"loader.h"

class Miner
{
public:
  Miner( CAUL& c, itemSet& is );
  ~Miner( void );
  void mine( void ); 

private:
  CAUL&     caul;
  itemSet&  IS;
  int*      flag;    //1 is valid, -1 is invalid
  int*      items;   //used in materialize_project
  double*   utils;   //used in materialize_project
  double    density; //the density of c

  void    dfs( int* W, int len, int up_sup, double up_util );
  int     closure( int* W, int len, int up_sup, double up_util );
  void    closure_output( int pos, double preutil, int* W, int len );
  int     pseudo_project( int* W, int i, int* relitem );
  int     pseudo_project_2( int item, int* relitem, int len );
  CAUL*   materialize_project( int item, int* relitem, int len );
  //double  get_preutil( int i );

  void  using_machine( int* W, int len );
  void  init_machine(  int len, int* label, int upbound );
  void  init_machine_anchor(  int len, int* label, int upbound, int anchor);  
};

#endif
