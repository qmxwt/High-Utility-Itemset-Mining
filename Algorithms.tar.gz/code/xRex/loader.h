#ifndef _loader
#define _loader


#include<memory.h>


class Element
{
public:
  double utility;
  double preutil;
  int    item;
  int    next;
};


class Entry
{
public:
  double utility;
  double uBitem;
  double uBfpe;
  int    support;
  int    next;
};


class CAUL
{
public:
  Element* dbase;
  Entry*   table;
  int*     itemname;
  int      itemnum;
  int      transnum;
  int      dblen;
  double   preutil;

  CAUL(int elenum, int tranum, int entnum)
  {
     dbase = (Element *)(new int[ 6L * ( elenum + tranum + 1 ) ]);
     table = (Entry *)(new int[ 8L * entnum ]);
     itemname = new int[ entnum ];
     itemnum = entnum;
     transnum = 0;
     preutil = 0.0;
  }

  ~CAUL(void)
  {
     delete []((int *)dbase);
     delete []((int *)table);
     delete []itemname;
  }
  
};


class Loader
{
public:
  CAUL* caul;
  Loader(char* trans_file, char* price_file, double percent);
  ~Loader(void);
  void show_caul(void);

private:
  FILE* trans;
  FILE* price;

  int      item_order;   //twu-asc(-1), lexi(0), twu-desc(1)
  int      item_number;  //the number of items in db
  int      trans_number; //the number of transactions in db
  double*  ex_util;
  int*     item_freq;
  double*  item_twu;
  
  void scan_price_file(void);
  void scan_trans_file(double percent);
  void init_caul(void);
  void create_caul(void);

  Element  key;
  void     sort_element(int low, int high);
  char*    cache;
  long     cache_size;
  void     amplify_cache(void);
};


#endif
