#include"common.h"
#include"loader.h"
#include"miner.h"


extern double MINUTIL;
extern Machine* m;
extern int ALPHA;       //The size of item machine
int ROUND = 3;          //Maximum number of # for irrelevant item filtering
double PHI = 0.5;       //Materialization threshold # for space-time tradeoff
long explored = 0;      //Explored itemsets


Miner::Miner( CAUL& c, itemSet& is ) 
  : caul( c ), IS( is )
{
   flag = new int[ caul.itemnum ];
   items = new int[ caul.itemnum ];
   utils = new double[ caul.itemnum ];
   density = ((double)caul.dblen) / caul.transnum ;
   density = density / caul.itemnum;
}
 

Miner::~Miner( void )
{
   delete []flag;
   delete []items;
   delete []utils;
}


void Miner::mine( void )
{
   int len = 0;
   for(int i=0; i<caul.itemnum; i++)
   {
      flag[i] = - 1;
      if( caul.table[i].uBitem >= MINUTIL )
	len++;
   }
   if( len == 0 )  return;

   int* relitem = new int[len];  //relevent items
   len = 0;
   for(int i=0; i<caul.itemnum; i++)
     if( caul.table[i].uBitem >= MINUTIL )
     {
        relitem[len] = i;
	len++;
     }
   dfs( relitem, len, caul.transnum, caul.preutil );
   delete []relitem;
}


void Miner::dfs( int* W, int len, int up_sup, double up_util )
{
   if( closure( W, len, up_sup, up_util ) ) //closure_or_singleton
     return;

   int smaller = len < ALPHA ? len : ALPHA;
   using_machine( W, smaller );

   explored += ( len - smaller );
   int* relitem = new int[ len ];  //relevent items
   for( int i=smaller; i<len; i++ )
   {
      int item = W[i];
      if( caul.table[item].utility >= MINUTIL )
	IS.output( caul.itemname[item], caul.table[item].utility );
      if( caul.table[item].uBfpe >= MINUTIL )
      {
	 IS.push( caul.itemname[item] );
	 int curlen = pseudo_project( W, i, relitem );
	 int lastlen = i;
	 int round = 1;
	 while( curlen!=0 && curlen!=lastlen && round<ROUND )
	 {
	    lastlen = curlen;
	    curlen = pseudo_project_2( item, relitem, curlen );
	    round++;
	 }
	 if( curlen > 0 )
	 {
	    if( density < PHI )
	      dfs( relitem, curlen, caul.table[item].support, caul.table[item].utility );
	    else
	    {
	       CAUL* sub_caul = materialize_project( item, relitem, curlen );
	       Miner sub_M( *sub_caul, IS );
	       sub_M.mine( );
	       delete sub_caul;
	    }
	 }
	 IS.pop( );
      }
   }
   delete []relitem;
}


int Miner::closure( int* W, int len, int up_sup, double up_util )
{
   int Closure = 1; //suppose Closure is OK
   double sumUtil = up_util;
   double minUtil = caul.table[W[0]].utility - up_util;
   
   for( int i=0; i<len; i++ )
   {
      if( caul.table[W[i]].support != up_sup )
	return 0;
      if( caul.table[W[i]].utility < MINUTIL )
	Closure = 0;
      double temp = caul.table[W[i]].utility - up_util;
      sumUtil += temp;
      if( minUtil > temp ) minUtil = temp;
   }
   if( Closure )
   {
      explored += (long)pow(2, len);
      for( int i=0; i<len; i++ )
	caul.table[W[i]].utility -= up_util;
      for( int i=0; i<len; i++ )
      {
	 double utility = up_util + caul.table[W[i]].utility;
	 IS.output( caul.itemname[W[i]], utility );
	 IS.push( caul.itemname[W[i]] );
	 closure_output( i+1, utility, W, len );
	 IS.pop( );
      }
      return 1;
   }////Closure property
   if( sumUtil >= MINUTIL && ( sumUtil - minUtil ) < MINUTIL )
   {
      explored++; 
      for( int i=0; i<len-1; i++ )
	IS.push( caul.itemname[W[i]] );
      IS.output( caul.itemname[W[len-1]], sumUtil );
      for( int i=0; i<len-1; i++ )
	IS.pop( );
      return 1;
   }////Singleton property
   return 0;
}


void Miner::closure_output( int pos, double preutil, int* W, int len )
{
   if( pos == len )
     return;
   
   closure_output( pos+1, preutil, W, len );
   double utility = preutil + caul.table[W[pos]].utility;
   IS.output( caul.itemname[W[pos]], utility );
   IS.push( caul.itemname[W[pos]] );
   closure_output( pos+1, utility, W, len );
   IS.pop( );
}


int Miner::pseudo_project( int* W, int i, int* relitem )
{
   if( i == 0 )
     return 0;
   
   for( int k=0; k<i; k++ )
   {
      int x = W[k];
      caul.table[x].utility = caul.table[x].uBitem\
	= caul.table[x].uBfpe = caul.table[x].support = 0;;
      caul.table[x].next = - 1;
      flag[x] = 1;
   }

   int next = caul.table[ W[i] ].next;
   while( next != - 1 )
   {
      double prefix = caul.dbase[next].preutil;  //get_preutil( next );
      double sum = prefix;
      int pos = next - 1;
      for( ; caul.dbase[pos].item != - 1 ; --pos )
	if( flag[ caul.dbase[pos].item ] == 1 )
	  sum += caul.dbase[pos].utility;
      double remain = prefix;
      for( int k=pos+1; k<next; k++ )
	if( flag[ caul.dbase[k].item ] == 1 )
	{
	   int x = caul.dbase[k].item;
	   caul.table[x].support++;
	   caul.table[x].utility += ( prefix + caul.dbase[k].utility );
	   remain += caul.dbase[k].utility;
	   caul.table[x].uBfpe += remain;
	   caul.table[x].uBitem += sum;
	   caul.dbase[k].preutil = prefix + caul.dbase[k].utility;
	   caul.dbase[k].next = caul.table[x].next;
	   caul.table[x].next = k;
	}
      next = caul.dbase[next].next;
   }

   int len = 0;
   for( int k=0; k<i; k++ )
   {
      flag[ W[k] ] = - 1;
      if( caul.table[W[k]].uBitem >= MINUTIL )
      {
	 relitem[len] = W[k];
	 len++;
      }
   }
   return len;
}


int Miner::pseudo_project_2( int item, int* relitem, int len )
{
   for( int k=0; k<len; k++ )
   {
      int x = relitem[k];
      caul.table[x].uBitem = caul.table[x].uBfpe = 0;
      flag[x] = 1;
   }

   int next = caul.table[ item ].next;
   while( next != - 1 )
   {
      double prefix = caul.dbase[next].preutil; //get_preutil( next );
      double sum = prefix;
      int pos = next - 1;
      for(  ; caul.dbase[pos].item != - 1; --pos )
	if( flag[ caul.dbase[pos].item ] == 1 )
	  sum += caul.dbase[pos].utility;
      double remain = prefix;
      for( int k=pos+1; k<next; k++ )
	if( flag[ caul.dbase[k].item ] == 1 )
	{
	   int x = caul.dbase[k].item;
	   remain += caul.dbase[k].utility;
	   caul.table[x].uBfpe += remain;
	   caul.table[x].uBitem += sum;
	}
      next = caul.dbase[next].next;
   }

   int curlen = 0;
   for( int k=0; k<len; k++ )
   {
      flag[ relitem[k] ] = - 1;
      if( caul.table[relitem[k]].uBitem >= MINUTIL )
      {
	 relitem[curlen] = relitem[k];
	 curlen++;
      }
   }
   return curlen;
}


CAUL* Miner::materialize_project( int item, int* relitem, int len )
{
   int elenum = 0;
   int tranum = caul.table[item].support;
   int entnum = 0;
   for( int k=0; k<len; k++ )
   {
      elenum += caul.table[relitem[k]].support;
      entnum++;
   }
   CAUL* sub_caul = new CAUL( elenum, tranum, entnum );

   int n = 0;
   for( int k=0; k<len; k++ )
   {
      sub_caul->table[n].uBfpe = caul.table[relitem[k]].uBfpe;
      sub_caul->table[n].uBitem = caul.table[relitem[k]].uBitem;
      sub_caul->table[n].support = caul.table[relitem[k]].support;
      sub_caul->table[n].utility = caul.table[relitem[k]].utility;
      sub_caul->table[n].next = - 1;
      sub_caul->itemname[n] = caul.itemname[relitem[k]];
      flag[relitem[k]] = n; //new labels
      n++;
   }
   sub_caul->preutil = caul.table[item].utility;
   sub_caul->transnum = caul.table[item].support;

   sub_caul->dbase[0].item = - 1;
   int lastele = 1;
   int next = caul.table[item].next;
   while( next != - 1 )
   {
      int cursor = entnum;
      items[cursor] = - 1;
      utils[cursor] = caul.dbase[next].preutil;
      double prefix = caul.dbase[next].preutil; //utils[cursor] = get_preutil( next );
      int k = next - 1;
      for( ; caul.dbase[k].item != -1; k-- )
	if( flag[caul.dbase[k].item]>=0 )
	{
	   cursor--;
	   items[cursor] = flag[caul.dbase[k].item];
	   utils[cursor] = caul.dbase[k].utility;
	}
      if( cursor < entnum )
      {
	 int upbound = entnum + 1;
	 int x = 0;
	 int y = cursor;
	 while( x < lastele )
	 {
	    x++; //skip the item of -1
	    while( x<lastele && y<upbound && sub_caul->dbase[x].item==items[y] )
	      {  x++; y++;  }
	    if( y == upbound )
	      break;
	    y = cursor;
	    while( x < lastele && sub_caul->dbase[x].item != -1 )
	      x++;
	 }
	 if( y == upbound )//merge the same transaction
	 {
	    sub_caul->transnum--;
	    x = x - ( upbound - cursor );
            y = cursor;
            while( y < entnum )
	    {
	       sub_caul->dbase[x].utility += utils[y];
	       sub_caul->dbase[x].preutil += ( prefix + utils[y] );  ///////
	       sub_caul->table[items[y]].support--;
	       x++;
	       y++;
	    }
            sub_caul->dbase[x].utility += utils[y];
	 }
	 else
	 {
	    x = lastele;
	    y = cursor;
	    while( y < entnum )
	    {
	       sub_caul->dbase[x].item = items[y];
	       sub_caul->dbase[x].utility = utils[y];
	       sub_caul->dbase[x].preutil = prefix + utils[y]; ////
	       sub_caul->dbase[x].next = sub_caul->table[items[y]].next;
	       sub_caul->table[items[y]].next = x;
	       x++;
	       y++;
	    }
	    sub_caul->dbase[x].item = - 1;  
            sub_caul->dbase[x].utility = utils[y];
            x++;
	    lastele = x;
	 }
      }
      next = caul.dbase[next].next;
   }
   sub_caul->dblen = lastele;

   for( int k=0; k<len; k++ )
     flag[relitem[k]] = - 1; 

   return sub_caul;
}


void Miner::using_machine( int* W, int len )
{
   int* name = new int[len];
   for( int i=0; i<len; i++ )
     name[i] = caul.itemname[W[i]];
   m->init( len, name );
   delete []name;
   
   int anchor = - 1;
   if( IS.top != 0 )
   {
      int item = IS.items[IS.top-1];
      for( int i=W[len-1]+1; i<caul.itemnum; i++ )
	if( item == caul.itemname[i] )
	  {  anchor = i;  break;  }
   }

   int* label = new int[W[len-1]+1];
   for(int i=0; i<=W[len-1]; i++)
     label[i] = - 1;
   for(int i=0; i<len; i++)
     label[W[i]] = i ;
   if( anchor < 0 )
     init_machine(  len, label, W[len-1] );
   else
     init_machine_anchor(  len, label, W[len-1], anchor );
   delete []label;

   m->run( len );
   m->close( );
}


void Miner::init_machine(  int len, int* label, int upbound )
{
   twosomeTable t(len);
   int i = 1;
   while( i < caul.dblen )
   {
      t.init( );
      for(  ; caul.dbase[i].item != -1 && caul.dbase[i].item <= upbound ; i++)
	if( label[caul.dbase[i].item] >= 0 )
	  t.append_twosome( label[caul.dbase[i].item], caul.dbase[i].utility );
      while( caul.dbase[i].item != -1 ) i++;
      double pre = caul.dbase[i].utility;
      if( t.usedLen > 0 )
	m->insert( t, pre );
      i++;
   }
}


void Miner::init_machine_anchor( int len, int* label, int upbound, int anchor )
{
   twosomeTable t(len);
   int next = caul.table[anchor].next;
   while( next != - 1)
   {
      int i = next;
      while( caul.dbase[i].item != -1 ) i--;
      i++;
      t.init( );
      for(  ; caul.dbase[i].item <= upbound ; i++)
	if( label[caul.dbase[i].item] >= 0 )
	  t.append_twosome( label[caul.dbase[i].item], caul.dbase[i].utility );
      double pre = caul.dbase[next].preutil; 
      if( t.usedLen > 0 )
	m->insert( t, pre );
      next = caul.dbase[next].next;
   }
}

