#include<stdio.h>
#include<memory.h>
#include"common.h"
#include"loader.h"
#include"miner.h"


extern double MINUTIL;
long explored = 0;


Miner::Miner( itemSet& is, int len ) : IS(is), tt(len)
{
   twu   = new double[len];
   freq  = new int[len];
   items = new int[len];
   item_order = 1;
   eachu = new double[len];
   eachi = new int[len];
}


Miner::~Miner(void)
{
   delete []twu;
   delete []freq;
   delete []items;
   delete []eachu;
   delete []eachi;
   printf("Search space : %ld\n", explored);
}


void Miner::mine( Tree& tree )
{
   explored += tree.itemnum;
   for(int i=tree.itemnum-1; i>=0; i--)     
     if( tree.utility[i] + tree.remutil[i] < MINUTIL )
       del_node_link( tree, i );
     else //>=
     {
       //if( ! single_branch( tree, i ) )
       //{	 
	   if( tree.utility[i] >= MINUTIL )
	     IS.output( tree.itemname[i], tree.utility[i] );
	   Tree* sub = init_sub_tree( tree, i );
	   if( sub == NULL )
	     del_node_link( tree, i );
	   else
	   {
	      IS.push( tree.itemname[i] );
	      construct_sub_tree( *sub, tree, i );
	      mine( *sub );
	      delete sub;
	      IS.pop( );
	   }
       //}
     }
}


int Miner::single_branch( Tree& tree, int pos )
{
   Node* p = tree.lstart[pos];
   if( p->link != NULL ) return 0;
   double  total = p->preutil + tree.upool[p->upos];
   double* u = tree.upool + p->upos - 1;
   endpos = 0;
   for( Node* q=p->parent; q->name!=-1; q=q->parent,u-- )
     if( tree.twuutil[q->name] >= MINUTIL )
     {
        eachi[endpos] = tree.itemname[q->name];
	eachu[endpos++] = *u; //++
	total += *u;
     }
   if( total >= MINUTIL )
   {
      if( endpos > 1 ) sort_each( 0 , endpos-1 );
      IS.push( tree.itemname[pos] );
      gen_compset( total, 0 );
      IS.pop( );
   }
   Node* q = p->parent;
   if( q->upos == -1 )
     q->upos = p->upos - 1;
   else
   {
      int i = 0;
      for( Node* t=q; t->name!=-1; t=t->parent,i++)
	tree.upool[q->upos-i] += tree.upool[p->upos-i-1]; //+=
   }
   P.delnode( p );
   return 1;
}


void Miner::gen_compset( double utility, int level )
{
   if( level == endpos )
   {
      IS.output( utility );
      return;
   }
   IS.push( eachi[level] );
   gen_compset( utility, level+1 );
   IS.pop( );
   utility = utility - eachu[level];
   if( utility >= MINUTIL )
     gen_compset( utility, level+1);
}


void Miner::sort_each( int low, int high )
{
   int i = low;
   int j = high;
   int keyitem = eachi[i];
   double key =  eachu[i];

   while( i != j )
   {
      while( i < j && key >= eachu[j] ) j--;
      if( i < j )
      {
         eachi[i] = eachi[j];
	 eachu[i] = eachu[j];
	 i++;
      }
      while( i < j && eachu[i] >= key ) i++;
      if( i < j )
      {
         eachi[j] = eachi[i];
	 eachu[j] = eachu[i];
	 j--;
      }
   }

   eachi[i] = keyitem;
   eachu[i] = key;
   if( low < (i-1) )
     sort_each( low, i-1 );
   if( (i+1) < high )
     sort_each( i+1, high );
}


Tree* Miner::init_sub_tree( Tree& tree, int pos )
{
   memset( twu, 0, pos * sizeof(double) );
   memset( freq, 0, pos * sizeof(int) );
   for( Node* p=tree.lstart[pos]; p!=NULL; p=p->link)
   {
      double* u = tree.upool + p->upos;
      double total = p->preutil + *u;
      top = 0;
      --u;
      for( Node* q=p->parent; q->name!=-1; q=q->parent, --u)
	if( tree.twuutil[q->name] >= MINUTIL  )
	{
	   items[top++] = q->name; //top++
	   total += *u;
	}
      for(int i=0; i<top; i++)
      {
	 twu[items[i]] += total;
	 freq[items[i]]++;
      }
   }

   tt.init( );
   int item_num = 0;
   int util_num = 0;
   for( int i=0; i<pos; i++ )
     if( twu[i] >= MINUTIL )
     {
        item_num++;
	util_num += freq[i];
	tt.append_twosome( i, twu[i] );
     }
     else
       freq[i] = - 1;
   if( item_num == 0 ) return NULL;
   switch( item_order )
   {
      case - 1 : tt.ascending_sort();  break;
      case 0   : tt.sort();            break;
      case 1   : tt.descending_sort(); break;
   }
   Tree* sub = new Tree( item_num, util_num );
   for( int i=0; i<tt.usedLen; i++ )
   {
      sub->itemname[i] = tree.itemname[tt.table[i].name];
      freq[ tt.table[i].name ] = i;
   }
   return sub;
}


extern Pool P;


void Miner::construct_sub_tree( Tree& sub, Tree& tree, int pos )
{
   for( Node* p=tree.lstart[pos]; p!=NULL; )
   {
      int num = 0;
      tt.init();
      double* u = tree.upool + p->upos;
      double preu = p->preutil + *u;
      double total = p->preutil + *u;
      --u;
      for( Node* q=p->parent; q->name!=-1; q=q->parent, --u)
      {
	 if( freq[q->name] >= 0  )
	 {
	    tt.append_twosome( freq[q->name], *u );
	    total += *u;
	 }
	 num++;
      }
      if( tt.usedLen > 0 )
	sub.insert_a_branch( tt, total, preu );

      Node* q = p->parent;
      if( q->upos == -1 )
	q->upos = p->upos - 1;
      else
	for(int i=0; i<num; i++)
	  tree.upool[q->upos-i] += tree.upool[p->upos-i-1]; //+=
      Node* last = p;
      p = p->link;
      P.delnode( last );
   }
}


void Miner::del_node_link( Tree& tree, int pos )
{
   for( Node* p=tree.lstart[pos]; p!=NULL; )
   {
      Node* q = p->parent;
      if( q->upos == -1 )
	q->upos = p->upos - 1;
      else
      {
	 int i = 0;
	 for( Node* t=q; t->name!=-1; t=t->parent,i++)
	   tree.upool[q->upos-i] += tree.upool[p->upos-i-1]; //+=
      }
      Node* last = p;
      p = p->link;
      P.delnode( last );
   }
}
