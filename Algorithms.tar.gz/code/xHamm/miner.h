#ifndef _miner
#define _miner


#include"common.h"
#include"loader.h"


class Miner
{
public:
  Miner( itemSet& is, int len );
  ~Miner( void );
  void mine( Tree& tree );

private:
  itemSet&     IS;
  twosomeTable tt; 
  double*      twu;
  int*         freq;
  int*         items;
  int          top;
  int          item_order;  //twu-asc(-1), lexical(0), twu-desc(1)
  Tree*        init_sub_tree( Tree& tree, int pos );
  void         construct_sub_tree( Tree& sub, Tree& tree, int pos );
  void         del_node_link( Tree& tree, int pos );

  double*      eachu;
  int*         eachi;
  int          endpos;
  int          single_branch( Tree& tree, int pos );
  void         gen_compset( double utility, int level );
  void         sort_each(int low, int high);
};

#endif
