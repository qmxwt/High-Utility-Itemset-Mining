#ifndef _loader
#define _loader


#include<memory.h>
#include"common.h"

class Node
{
public:
  int     name;
  int     upos;
  double  preutil;
  Node*   link;
  Node*   parent;
  Node*   sibling;
  Node*   child;
};


class Pool
{
public:
  Pool(void);
  ~Pool(void);
  Node* getnode( int item );
  void  delnode( Node* p );
private:
  int   nodesize;
  int   blocksize;
  int   current;
  char* blocks;
  Node* freenode;
  long  total;
};


extern Pool P;


class Tree
{
private:
  int     UPOS;
  
public:
  int     itemnum;
  int*    itemname;
  double* utility;
  double* remutil;
  double* twuutil;
  Node**  lstart;
  
  Node*   root;
  double* upool;

  Tree(int item_num, int util_num) : UPOS(0), itemnum(item_num)
  {
     itemname = new int[ itemnum ];
     utility  = new double[ itemnum ];
     remutil  = new double[ itemnum ];
     twuutil  = new double[ itemnum ];
     lstart   = new Node*[ itemnum ];
     memset( utility, 0, itemnum * sizeof(double) );
     memset( remutil, 0, itemnum * sizeof(double) );
     memset( twuutil, 0, itemnum * sizeof(double) );
     memset( lstart,  0, itemnum * sizeof(Node*) );
     root = P.getnode( - 1 );
     upool = new double[ util_num ];
  }

  ~Tree(void)
  {
    delete []itemname;
    delete []utility;
    delete []remutil;
    delete []twuutil;
    delete []lstart;
    delete []upool;
    P.delnode( root );
  }

  void insert_a_branch( twosomeTable &t, double twu, double pu );
};


class Loader
{
public:
  Tree* tree;
  Loader( char* trans_file, char* price_file, double percent );
  ~Loader( void );

private:
  FILE* trans;
  FILE* price;

  int     item_order;  //twu-asc(-1), lexical(0), twu-desc(1)
  int     item_number; //the number of items in db
  int*    item_freq;
  double* item_twu;
  double* ex_util;

  void scan_price_file( void );
  void scan_trans_file( double percent );
  void init_tree( void );
  void create_tree( void );

  char* cache;
  long  cache_size;
  void  amplify_cache(void);
};

//////////////////////For TEST
void print_tree( Tree* tree );

#endif
