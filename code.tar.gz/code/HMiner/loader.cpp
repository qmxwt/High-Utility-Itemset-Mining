#include<stdio.h>
#include<stdlib.h>
#include<glib.h>
#include"common.h"
#include"loader.h"


extern double       MINUTIL;
extern int          ITERDEPTH;
extern int          EUCS_PRUNE;
extern GHashTable*  EUCST;


void free_key_value( gpointer key, gpointer value, gpointer user_data )
{
   delete [](int*)key;
   delete (double*)value;
}


Loader::Loader(char* trans_file, char* price_file, double percent)
  :  cul(NULL), culnum(0)
{
   trans = fopen( trans_file, "rt" );
   if( trans==NULL )
   {
      printf("Transaction file cannot open!\n");
      exit(0);
   }
   price = fopen( price_file, "rt" );
   if( price==NULL )
   {
      printf("Price file cannot open!\n");
      fclose( trans );
      exit(0);
   }

   scan_price_file( );
   //item_* and cache are allocated, ex_util is assigned
   scan_trans_file( percent );
   //variables item_*, trans_number and MINUTIL are assigned
   item_order = - 1;
   init_cul( );
   create_cul( );
   //caul is constructed

   delete []ex_util;
   delete []item_freq;
   delete []item_twu;
   delete []cache;
   fclose( trans );
   fclose( price );
}


Loader::~Loader(void)
{
   for( int i=0; i<culnum; i++ )
     delete []cul[i].list;
   delete []cul;
   if( EUCS_PRUNE )
     g_hash_table_destroy( EUCST );
}


void Loader::scan_price_file(void)
{
   fseek( price, 0, SEEK_END );
   long ch_num = ftell( price );
   cache = new char[ ch_num ];
   cache_size = ch_num;
   fseek( price, 0, SEEK_SET );
   fread( cache, ch_num, 1, price );

   item_number = 0;
   long i = 0;
   for( ; i<ch_num; i++ )
     if( cache[i]=='\n' )
       item_number++;

   ex_util = new double[ item_number ];
   int j = 0;
   double temp;

   i = 0;
   while( i<ch_num )
   {
      temp = 0;
      while( cache[i]>='0' && cache[i]<='9' )
        temp = temp * 10 + (double)(cache[i++] - '0'); //i++
      if( cache[i]=='.' )
      {
	 i++;  //skip '.'
	 double reduce = (double)0.1;
	 while( cache[i]>='0' && cache[i]<='9' )
	 {
	    temp += (double)(cache[i++] - '0') * reduce ;  //i++
	    reduce *= (double)0.1;
	 }
      }
      i++;  //skip '\n'
      ex_util[j++] = temp;  //j++
   }

   item_freq = new int[ item_number ];
   memset( item_freq, 0, item_number*sizeof(int) );
   item_twu = new double[ item_number ];
   memset( item_twu, 0, item_number*sizeof(double) );
}


void Loader::amplify_cache(void) //add 64k
{
   long len = cache_size + 64 * 1024;
   char* temp =new char[len];
   memcpy(temp, cache, cache_size);
   delete []cache;
   cache = temp;
   cache_size = len;
}


void Loader::scan_trans_file(double percent)
{
   trans_number = 0;
   double total_util = 0;
   int* items = new int[item_number];
   int top;

   long ch_num;
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans ); //!!return count
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	      amplify_cache();
	 }while( c!='\n' );
      }

      long i = 0;
      int item;
      int quantity;
      double trans_util;
      while( i<ch_num )
      {
	 trans_util = 0;
	 top = 0;
	 while( 1 )
	 {
	    item = quantity = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + (int)( cache[i++] - '0' );  //i++
	    items[top++] = item;  //top++
	    i++;  //skip ' '
	    while( cache[i]>='0' && cache[i]<='9' )
	      quantity = quantity * 10 + (int)( cache[i++] - '0' );  //i++
	    trans_util += ( ex_util[item] * (double)quantity );
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break;  }  //skip '\n'
	 }////get a transaction
	 trans_number++;
	 for( int j=0; j<top; j++ )
	 {
	    item_freq[ items[j] ] ++;
	    item_twu[ items[j] ] += trans_util;
	 }
	 total_util += trans_util;
      }
   }while( !feof(trans) );

   delete []items;
   MINUTIL = total_util * percent ;
}


void Loader::init_cul(void)
{
   twosomeTable t(item_number);
   int i = 0;
   for( ; i<item_number; i++ )
     if( item_twu[i] >= MINUTIL )
       t.append_twosome( i, item_twu[i] );
     else
       item_freq[i] = - 1;
   ITERDEPTH = t.usedLen + 1;
   cul = new CUL[t.usedLen];
   culnum = t.usedLen;
   
   switch( item_order )
   {
      case  -1  :  t.ascending_sort();   break;
      case   0  :  t.sort();   break;
      case   1  :  t.descending_sort();  break;
   }
   for( i=0; i<t.usedLen; i++ )
   {
      cul[i].NU = cul[i].NRU = cul[i].CU = cul[i].CRU = cul[i].CPU = 0;
      cul[i].list = new Element[item_freq[t.table[i].name]];
      cul[i].len = 0;
      cul[i].name = t.table[i].name;
      item_freq[t.table[i].name] = i; //newid
   }

   if( EUCS_PRUNE )
     EUCST = g_hash_table_new( g_int64_hash, g_int64_equal );
}




void Loader::create_cul(void)
{
   int* items = new int[culnum+1];
   int top = 0;
   doubArr da(culnum+1);
   GHashTable* HT = g_hash_table_new_full( g_str_hash, g_str_equal, g_free, g_free );

   int  tid = 0;
   long ch_num;
   int  max_trans_len = 0;
   fseek( trans, 0, SEEK_SET );
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans );
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	       amplify_cache();
	 }while( c!='\n' );
      }

      double twu;
      int item;
      int quantity;
      int i = 0;
      while( i<ch_num )
      {
	 top = 0;
	 twu = 0;
	 da.init();
	 while( 1 )
	 {
	    item = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + int( cache[i++] - '0' );  //i++
	    i++;  //skip ' '
	    if( item_freq[item] >= 0 )
	    {
	       items[top++] = item;
	       quantity = 0;
	       while( cache[i]>='0' && cache[i]<='9' )
		 quantity = quantity * 10 + int( cache[i++] - '0' );  //i++
	       da.append( item_freq[item], ex_util[item]*quantity );
	       twu += ex_util[item]*quantity;
	    }
	    else
	      while( cache[i]>='0' && cache[i]<='9' ) i++;
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break; }  //skip '\n'
	 }////get a transaction
	 if( da.len == 0 ) continue; //invalid transaction
	 if( da.len > max_trans_len ) max_trans_len = da.len;
	 da.sort( );
	 char* str = da.tostring();
	 int* ele = (int *)g_hash_table_lookup( HT, (gpointer)str );
	 if( ele != NULL )
	 {
	    int next = *ele;
	    double remain = 0;
	    for(int i=da.len-1; i>=0; i--)
	    {
	       int item = da.t[i];
	       cul[item].NU += da.u[i];
	       cul[item].NRU += remain;
	       cul[item].list[next].nu += da.u[i];
	       cul[item].list[next].nru += remain;
	       remain += da.u[i];
	       next = cul[item].list[next].ppos;
	    }
	 }
	 else
	 {
	    Element* last = NULL;
	    double remain = 0;
	    for(int i=da.len-1; i>=0; i--)
	    {
	       int item = da.t[i];
	       cul[item].NU += da.u[i];
	       cul[item].NRU += remain;
	       if( last != NULL ) last->ppos = cul[item].len;
	       last = cul[item].list + cul[item].len;
	       last->nu = da.u[i];
	       last->nru = remain;
	       last->npu = 0;
	       last->tid = tid;
	       remain += da.u[i];
	       cul[item].len++;
	    }
	    last->ppos = - 1;
	    tid++;
	    char* str2 = (char *)g_malloc( strlen(str) + 1 );
	    int* v = (int *)g_malloc( sizeof(int) );
	    strcpy( str2, str );
	    *v = cul[da.t[da.len-1]].len - 1;
	    g_hash_table_insert( HT, (gpointer)str2, (gpointer)v );
	 }
	 if( EUCST != NULL )
	 {
	    for(int i=0; i<top-1; i++)
	      for(int j=i+1; j<top; j++)
	      {
		 int x[2] = { items[i], items[j] };
		 double* value = (double *)g_hash_table_lookup( EUCST, (gconstpointer)x );
		 if( value != NULL )
		   *value = *value + twu;
		 else
		 {
		    int* key = new int[2];
		    key[0] = x[0];
		    key[1] = x[1];
		    value = new double;
		    *value = twu;
		    g_hash_table_insert( EUCST, (gpointer)key, (gpointer)value );
		 }  
	      }
	 }
      }
   }while( !feof(trans) );

   if ( ITERDEPTH > max_trans_len )
     ITERDEPTH = max_trans_len + 1;

   g_hash_table_destroy( HT );
   delete []items;
}
