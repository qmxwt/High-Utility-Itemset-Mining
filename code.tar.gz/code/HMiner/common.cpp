#include<glib.h>
#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include"common.h"


double        MINUTIL;
int           ITERDEPTH;
int           EUCS_PRUNE = 1; // 1 prune; 0 no prune
GHashTable*   EUCST = NULL;
int           ACCURACY = 1000000; 


/////////////////////rewrite new and delete//////////////////////////////////////
long current = 0;
long peak = 0;

void* operator new( size_t sz )
{
   sz = sz + 8;
   void* m = malloc( sz );
   if( !m )
   {
      printf("Out of memory!\n");
      exit( 0 );
   }
   long* x = (long *)m;
   *x = sz;
   x = x + 1;

   current += sz;
   if( peak < current )
     peak = current;

   return (void *)x;
}

void operator delete( void* m )
{
   long* x = (long *)m;
   x = x - 1;
   current -= *x;
   free( (void *)x );
}

void* operator new[]( size_t sz )
{
   sz = sz + 8;
   void* m = malloc( sz );
   if( !m )
   {
      printf("Out of memory!\n");
      exit( 0 );
   }
   long* x = (long *)m;
   *x = sz;
   x = x + 1;

   current += sz;
   if( peak < current )
     peak = current;

   return (void *)x;
}

void operator delete[]( void* m )
{
   long* x = (long *)m;
   x = x - 1;
   current -= *x;
   free( (void *)x );
}
//////////////////////////////////////////////////////////////////////////




//////////////////////// Class twosomeTable /////////////////////////////
void twosomeTable::descending_sort(int low, int high)
{
   int i = low;
   int j = high;
   key_twosome = table[i];
   key_value = key_twosome.value;

   while( i!=j )
   {
      while( i<j && key_value>=table[j].value )
        j--;
      if( i<j )
        table[i++] = table[j];
      while( i<j && table[i].value>=key_value )
        i++;
      if( i<j )
        table[j--] = table[i];
   }

   table[i] = key_twosome;
   if( low < (i-1) )
     descending_sort( low, i-1 );
   if( (i+1) < high )
     descending_sort( i+1, high );
}

void twosomeTable::ascending_sort(int low, int high)
{
   int i = low;
   int j = high;
   key_twosome = table[i];
   key_value = key_twosome.value;

   while( i!=j )
   {
      while( i<j && key_value<=table[j].value )
        j--;
      if( i<j )
        table[i++] = table[j];
      while( i<j && table[i].value<=key_value )
        i++;
      if( i<j )
        table[j--] = table[i];
   }

   table[i] = key_twosome;
   if( low < (i-1) )
     ascending_sort( low, i-1 );
   if( (i+1) < high )
     ascending_sort( i+1, high );
}

void twosomeTable::sort(int low, int high)
{
   int i = low;
   int j = high;
   key_twosome = table[i];
   key_name = key_twosome.name;

   while( i!=j )
   {
      while( i<j && key_name<=table[j].name )
        j--;
      if( i<j )
        table[i++] = table[j];
      while( i<j && table[i].name<=key_name )
        i++;
      if( i<j )
        table[j--] = table[i];
   }

   table[i] = key_twosome;
   if( low < (i-1) )
     sort( low, i-1 );
   if( (i+1) < high )
     sort( i+1, high );
}
//////////////////////////////////////////////////////////////////////////




/////////////////////////// Class itemSet ////////////////////////////////
itemSet::itemSet(int len, char* filename)
{
   items = new int[len];
   top = 0;
   results = new long[len];
   memset( results, 0, len * sizeof(long) );
   upbound = len;
   if( filename!=NULL )
   {
      outflag = 1;
      outfile = fopen( filename, "w" );
      if( outfile==NULL )
      {
	 printf("Cannot output to %s\n", filename);
	 exit(0);
      }
   }
   else
     outflag = 0;

   preitems[0] = ' ';
   pretop = 1;
   buf = new char[ 64 * 1024 ];
   bound = 4 * 1024;
   current = 64 * 1024 - 1 ;
}

itemSet::~itemSet(void)
{
   delete []items;
   delete []results;
   if( outflag )
   {
     if( current != 64 * 1024 - 1 )
       fwrite( buf+current+1, 64*1024-current-1, 1, outfile );
     fclose( outfile );
   }
   delete []buf;
}

void itemSet::show(void)
{
   int i = 0;
   long total = 0;
   for( ; i<upbound; i++ )
     if( results[i]!=0 )
     {
        printf( "%ld\n", results[i] );
	total += results[i];
     }
   printf("Total number of itemsets : %ld\n", total);
}


void itemSet::output( int item, double utility )
{
   results[top]++;
   if( outflag )
   {
      buf[current--] = '\n';
      buf[current--] = ')';
      int intpart = (int)utility;
      int decpart = (int)((utility - intpart) * ACCURACY);
      do
      {
	 buf[current--] = (char)(decpart % 10 + 48);
	 decpart = decpart / 10;
      }while( decpart != 0 );
      buf[current--] = '.';
      do
      {
	 buf[current--] = (char)(intpart % 10 + 48);
	 intpart = intpart / 10;
      }while( intpart != 0 );
      buf[current--] = '(';
      buf[current--] = ' ';
      do
      {
	 buf[current--] = (char)(item % 10 + 48);
	 item = item / 10;
      }while( item != 0 );
      for(int i=pretop-1; i>0; i--)
	buf[current--] = preitems[i];
      if( current <= bound )
      {
	 fwrite( buf+current+1, 64*1024-current-1, 1, outfile );
	 current = 64 * 1024 - 1;
      }
   }
}


void itemSet::output( double utility )
{
   results[top-1]++;
   if( outflag )
   {
      buf[current--] = '\n';
      buf[current--] = ')';
      int intpart = (int)utility;
      int decpart = (int)((utility - intpart) * ACCURACY);
      do
      {
	 buf[current--] = (char)(decpart % 10 + 48);
	 decpart = decpart / 10;
      }while( decpart != 0 );
      buf[current--] = '.';
      do
      {
	 buf[current--] = (char)(intpart % 10 + 48);
	 intpart = intpart / 10;
      }while( intpart != 0 );
      buf[current--] = '(';
      for(int i=pretop-1; i>0; i--)
	buf[current--] = preitems[i];
      if( current <= bound )
      {
	 fwrite( buf+current+1, 64*1024-current-1, 1, outfile );
	 current = 64 * 1024 - 1;
      }
   }
}
//////////////////////////////////////////////////////////////////////////




//////////////////////////// Class doubArr ////////////////////////////////
void doubArr::sort(int low, int high, int* t, double* u)
{
   int i = low;
   int j = high;
   int t_key = t[i];
   double u_key = u[i];

   while( i!=j )
   {
      while( i < j && t_key < t[j] )  j--;
      if( i<j )
      {
	 t[i] = t[j];
	 u[i] = u[j];
	 i++;
      }
      while( i < j && t[i] < t_key )  i++;
      if( i<j )
      {
	 t[j] = t[i];
	 u[j] = u[i];
	 j--;
      }
   }
   t[i] = t_key;
   u[i] = u_key;
   if( low < (i-1) )   sort( low, i-1, t, u );
   if( (i+1) < high )  sort( i+1, high, t, u );
}
///////////////////////////////////////////////////////////////////////////
