#ifndef _common
#define _common


#include<stdio.h>
#include<string.h>


void* operator new( size_t sz );
void operator delete( void* m );
void* operator new[]( size_t sz );
void operator delete[]( void* m );


class twosome
{
public:
  int    name;
  double value;
};

class twosomeTable
{
public:
  twosome*  table;
  int       usedLen;
  //the used length of table, table[ 0<-->(usedLen-1) ]

  inline twosomeTable(int len) : usedLen(0)
  {  table = new twosome[len];  }

  inline ~twosomeTable(void)
  {  delete []table;  }

  inline void init(void)
  {  usedLen = 0;  }

  inline void append_twosome(int x, double v)
  {
     table[usedLen].name = x;
     table[usedLen++].value = v;
  }

  inline void descending_sort(void)
  {
     if( usedLen>=2 )
       descending_sort(0, usedLen-1);
  }////sort in value-descending order

  inline void ascending_sort(void)
  {
     if( usedLen>=2 )
       ascending_sort(0, usedLen-1);
  }////sort in value-ascending order

  inline void sort(void)
  {
     if( usedLen>=2 )
       sort(0, usedLen-1);
  }////sort in name-ascending order

private:
  twosome key_twosome;
  int     key_name;
  double  key_value;
  ////work for the following functions
  void descending_sort(int low, int high);
  void ascending_sort(int low, int high);
  void sort(int low, int high);
  ////these three functions are called by the above cognominal functions
};




class itemSet
{
public:
  int*   items;
  int    top;
  itemSet(int len, char* filename);
  ~itemSet(void);
  void show(void);

  inline void push(int item)
  {
     items[top++] = item;
     char temp[20];
     int i = 19;
     temp[19] = (char)(item % 10 + 48);
     item = item / 10;
     while( item != 0 )
     {
        i--;
	temp[i] = (char)(item % 10 + 48);
	item = item / 10;
     }
     while( i < 20 )
       preitems[pretop++] = temp[i++]; //++
     preitems[pretop++] = ' ';
  }

  inline void pop(void)
  {
     top--;
     pretop -= 2;
     while( preitems[pretop] != ' ' )
       pretop--;
     pretop++;
  }

  void output(int item, double utility);
  void output( double utility );

private:
  long*  results;
  int    upbound;
  int    outflag; //1 output; 0 dont output
  FILE*  outfile;

  char    preitems[10000];
  int     pretop;
  char*   buf;
  int     bound;
  int     current;
};




class doubArr
{
public:
  int*     t;
  double*  u;
  char*    str;
  int      len;
  doubArr( int l ) : len(0)
  {
     t = new int[l];
     u = new double[l];
     str = new char[10*l];
  }
  ~doubArr( void )
  {
     delete []t;
     delete []u;
     delete []str;
  }
  inline void init( void )
  {
     len = 0;
  }
  inline void append(int tt, double uu)
  {
     t[len] = tt;
     u[len] = uu;
     len++;
  }
  inline void sort( void )
  {
     if( len > 1 )
       sort( 0, len-1, t, u );
  }
  inline char* tostring( void )
  {
     char temp[12];
     str[0] = '\0';
     for( int i=0; i<len; i++ )
     {
	sprintf( temp, "%d ", t[i]);
	strcat( str, temp );
     }
     return str;
  }
  
private:
  void sort(int low, int high, int* t, double* u);
};




#endif

