#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include"common.h"
#include"loader.h"


extern double MINUTIL;
Pool P;


//////////////////////////// class Pool ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////
Pool::Pool(void)
{
   nodesize = sizeof( Node );
   blocksize = nodesize * 1301; //1300 nodes slightly less than 64k
   blocks = new char[blocksize];
   (*((char**)blocks)) = NULL;
   current = 1;
   freenode = NULL;
   total = 0;
}


Pool::~Pool(void)
{
   while( blocks != NULL )
   {
      char* next = *((char**)blocks);
      delete []blocks;
      blocks = next;
   }
   printf("Generated nodes: %ld\n", total);
}


Node* Pool::getnode( int item )
{
   total++;
   Node *n = NULL;
   if( freenode != NULL )
   {
      n = freenode;
      freenode = freenode->link;
   }
   else
   {
      n = ((Node *)blocks) + current;
      current++;
      if( current == 1301 )
      {
	 char* temp = new char[blocksize];
	 (*((char**)temp)) = blocks;
	 blocks = temp;
	 current = 1;
      }
   }
   n->name = item;
   n->upos = - 1;
   n->preutil = 0;
   n->link = n->parent = n->sibling = n->child = NULL;
   return n;
}


void Pool::delnode( Node* p )
{
   p->link = freenode;
   freenode = p;
}
///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////




//////////////////////////// class Tree////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
void Tree::insert_a_branch( twosomeTable &t, double twu, double pu )
{
   t.sort();
   Node* p = root;
   double rem = 0;
   for(int i=0; i<t.usedLen; i++)
   {
      Node* parent_p = p;
      Node* last = NULL;
      p = p->child;
      while( p != NULL && t.table[i].name > p->name )
      {
	 last = p;
	 p = p->sibling;
      }
      if( p == NULL || (p!=NULL && t.table[i].name<p->name) )
      {
	 p = P.getnode( t.table[i].name );
	 if( last == NULL ) //the fist child node
	 {
	    p->sibling = parent_p->child;
	    parent_p->child = p;
	 }
	 else
	 {
	    p->sibling = last->sibling;
	    last->sibling = p;
	 }
	 p->parent = parent_p;
	 p->link = lstart[t.table[i].name];
	 lstart[t.table[i].name] = p;
      }
      p->preutil += pu;
      utility[p->name] += t.table[i].value + pu;
      remutil[p->name] += rem;
      rem += t.table[i].value;
      twuutil[p->name] += twu;
   }
   if( p->upos != - 1 )
     for(int i=0; i<t.usedLen; i++)
       upool[p->upos-i] += t.table[t.usedLen-i-1].value;
   else
   {
      for(int i=0; i<t.usedLen; i++)
	upool[UPOS++] = t.table[i].value; //UPOS++
      p->upos = UPOS -1;
   }
}
///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////




//////////////////////////// class Loader /////////////////////////////////
///////////////////////////////////////////////////////////////////////////
Loader::Loader(char* trans_file, char* price_file, double percent)
  :  tree(NULL)
{
   trans = fopen( trans_file, "rt" );
   if( trans == NULL )
   {
      printf("Transaction file cannot open!\n");
      exit(0);
   }
   price = fopen( price_file, "rt" );
   if( price == NULL )
   {
      printf("Price file cannot open!\n");
      fclose( trans );
      exit(0);
   }

   scan_price_file( );
   //item_* and cache are allocated, ex_util is assigned
   scan_trans_file( percent );
   //variables item_* and MINUTIL are assigned
   item_order = 1;
   init_tree( );
   create_tree( );
   //tree is constructed

   delete []ex_util;
   delete []item_freq;
   delete []item_twu;
   delete []cache;
   fclose( trans );
   fclose( price );
}


Loader::~Loader( void )
{
   delete tree;
}


void Loader::scan_price_file(void)
{
   fseek( price, 0, SEEK_END );
   long ch_num = ftell( price );
   cache = new char[ ch_num ];
   cache_size = ch_num;
   fseek( price, 0, SEEK_SET );
   fread( cache, ch_num, 1, price );

   item_number = 0;
   long i = 0;
   for( ; i<ch_num; i++ )
     if( cache[i]=='\n' )
       item_number++;

   ex_util = new double[ item_number ];
   int j = 0;
   double temp;

   i = 0;
   while( i<ch_num )
   {
      temp = 0;
      while( cache[i]>='0' && cache[i]<='9' )
        temp = temp * 10 + (double)(cache[i++] - '0'); //i++
      if( cache[i]=='.' )
      {
	 i++;  //skip '.'
	 double reduce = (double)0.1;
	 while( cache[i]>='0' && cache[i]<='9' )
	 {
	    temp += (double)(cache[i++] - '0') * reduce ;  //i++
	    reduce *= (double)0.1;
	 }
      }
      i++;  //skip '\n'
      ex_util[j++] = temp;  //j++
   }

   item_freq = new int[ item_number ];
   memset( item_freq, 0, item_number*sizeof(int) );
   item_twu = new double[ item_number ];
   memset( item_twu, 0, item_number*sizeof(double) );
}


void Loader::amplify_cache(void) //add 64k
{
   long len = cache_size + 64 * 1024;
   char* temp =new char[len];
   memcpy(temp, cache, cache_size);
   delete []cache;
   cache = temp;
   cache_size = len;
}


void Loader::scan_trans_file(double percent)
{
   double total_util = 0;
   int* items = new int[item_number];
   int top;

   long ch_num;
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans ); //!!return count
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	      amplify_cache();
	 }while( c!='\n' );
      }

      long i = 0;
      int item;
      int quantity;
      double trans_util;
      while( i<ch_num )
      {
	 trans_util = 0;
	 top = 0;
	 while( 1 )
	 {
	    item = quantity = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + (int)( cache[i++] - '0' );  //i++
	    items[top++] = item;  //top++
	    i++;  //skip ' '
	    while( cache[i]>='0' && cache[i]<='9' )
	      quantity = quantity * 10 + (int)( cache[i++] - '0' );  //i++
	    trans_util += ( ex_util[item] * (double)quantity );
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break;  }  //skip '\n'
	 }////get a transaction
	 for(int j=0; j<top; j++ )
	 {
	    item_freq[ items[j] ] ++;
	    item_twu[ items[j] ] += trans_util;
	 }
	 total_util += trans_util;
      }
   }while( !feof(trans) );

   delete []items;
   MINUTIL = total_util * percent ;
}


void Loader::init_tree( void )
{
   twosomeTable t(item_number);
   int freq = 0;
   int i = 0;
   for( ; i<item_number; i++ )
     if( item_twu[i] >= MINUTIL )
     {
        freq += item_freq[i];
        t.append_twosome( i, item_twu[i] );
     }
     else
       item_freq[i] = - 1;
   tree = new Tree( t.usedLen, freq );

   switch( item_order )
   {
      case - 1 : t.ascending_sort();  break;
      case 0   : t.sort();            break;
      case 1   : t.descending_sort(); break;
   }
   for( i=0; i<t.usedLen; i++ )
   {
       tree->itemname[i] = t.table[i].name;
       //tree->utility[i] = tree->remutil[i] = tree->twuutil[i] = 0;
       //tree->lstart[i] = NULL;
       item_freq[t.table[i].name] = i;
   }
}


void Loader::create_tree(void)
{
   twosomeTable t(item_number);
   long ch_num;
   fseek( trans, 0, SEEK_SET );
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans );
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	       amplify_cache();
	 }while( c!='\n' );
      }

      int i = 0;
      int item;
      int quantity;
      while( i<ch_num )
      {
	 double twu = 0;
	 t.init( );
	 while( 1 )
	 {
	    item = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + int( cache[i++] - '0' );  //i++
	    i++;  //skip ' '
	    if( item_freq[item]>=0 )
	    {
	       quantity = 0;
	       while( cache[i]>='0' && cache[i]<='9' )
		 quantity = quantity * 10 + int( cache[i++] - '0' );  //i++
	       double utility = ex_util[item] * quantity;
	       t.append_twosome( item_freq[item], utility );
	       twu += utility;
	    }
	    else
	      while( cache[i]>='0' && cache[i]<='9' ) i++;
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break; }  //skip '\n'
	 }////get a transaction
	 if( t.usedLen != 0 )
	   tree->insert_a_branch( t, twu, 0 );
      }
   }while( !feof(trans) );
}



///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////

int depth  = 0;

void print_node( Node* n, double* upool)
{
  printf("name : %d  ", n->name);
  printf("upos : %d\n", n->upos);
  if( n->upos >= 0 )
    for(int i=0; i<depth; i++)
      printf("%lf ", upool[n->upos-i]);
  printf("\n-------------------\n");

  depth++;
  Node *c = n->child;
  while ( c != NULL )
  {
     print_node( c, upool );
     c = c->sibling;
  }
  depth--;
}


void print_tree( Tree* tree)
{
  printf( "item %d ------------------------------------\n", tree->itemnum );
  printf("name\t\t\tutil\t\t\trem\t\t\ttwu\n");
  for(int i=0; i<tree->itemnum; i++)
  {
     printf("%d\t\t\t",  tree->itemname[i] );
     printf("%lf\t\t\t", tree->utility[i] );
     printf("%lf\t\t\t", tree->remutil[i] );
     printf("%lf\n", tree->twuutil[i] );
  }
  printf( "----------------------------------------\n" );

  depth = 0;
  print_node( tree->root, tree->upool );
}
