#ifndef _miner
#define _miner


#include"common.h"
#include"loader.h"


class Projection
{
public:
  int     len;       //the size of Projection
  int     cur;       //the factual length of the current Projection
  double* preutil;   //the prefix utility
  int*    pos;       //> 0 trans in DS;  < 0 in TB;  = 0 a null tran in TB
  int*    pri;       //the primary set
  int*    sec;       //the secondary set
  int     pnum;      //the size of Pri
  int     snum;      //the size of Sec
  Projection( int le, int nu );
  ~Projection( void );
  void show( void );
};


class Miner
{
public:
  Dataset& DS;
  Tbuffer& TB;
  itemSet& IS;
  Miner( Dataset& ds, Tbuffer& tb, itemSet& is, int len );
  ~Miner( void );
  void mine( void );
private:
  double*  lu;
  double*  su;
  int*     mapp;
  void     search( int level, Projection& pdb );
  double   create_projection( int level, Projection& pdb, int no, Projection& sub, int upbound );
  void     calculate_lu_su( int& cursor, int level, Projection& pdb, int no, Projection& sub );
};

#endif
