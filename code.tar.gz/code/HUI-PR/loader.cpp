#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include"common.h"
#include"loader.h"


extern double MINUTIL;


//////////////////////////// class Dataset///////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
Dataset::Dataset( int freq_num, int tran_num, int item_num )
{
   memsize = freq_num + tran_num + 1; //having an end
   items = new int[ memsize ];
   utils = new double[ memsize ];
   index = new int[ tran_num ];
   preutil = new double[ tran_num ];
   trannum = 0;  //Empty trans would not be saved
   mempos = 0;
   itemnum = item_num;
   support = new int[ item_num ];
   itemname = new int[ item_num ];
}


Dataset::~Dataset( void )
{
   delete []items;
   delete []utils;
   delete []index;
   delete []preutil;
   delete []support;
   delete []itemname;
}


//Assure t is not null and is sorted
void Dataset::apptran( twosomeTable& t, double twu, double pu )
{
   index[trannum] = mempos;
   preutil[trannum++] = pu; //++
   items[mempos] = - t.usedLen; 
   utils[mempos++] = twu;   //++
   for( int i=0; i<t.usedLen; i++,mempos++ )
   {
      items[mempos] = t.table[i].name;
      utils[mempos] = t.table[i].value;
      support[t.table[i].name]++;
   }
   items[mempos] = - 1;
}


void Dataset::sortds( void )
{
   if( trannum > 1 )
     sortds( 0, 0, trannum-1 );
}


void Dataset::sortds( int pos, int low, int high )
{
   int object = items[ index[low] - items[index[low]] - pos ];
   int lt = low;
   int gt = high;
   int cur = low + 1;

   while( cur <= gt )
     if( items[ index[cur] - items[index[cur]] - pos ] < object )
     {
        int temp = index[cur];
	index[cur] = index[lt];
	index[lt] = temp;
	double tempd = preutil[cur];
	preutil[cur] = preutil[lt];
	preutil[lt] = tempd;
	lt++;
	cur++;
     }
     else
       if( items[ index[cur] - items[index[cur]] - pos ] == object )
	 cur++;
       else
       {
	  while( cur <= gt && items[ index[gt] - items[index[gt]] - pos ] > object )
	    gt--;
	  if( cur < gt )
	  {
	     int temp = index[cur];
	     index[cur] = index[gt];
	     index[gt] = temp;
	     double tempd = preutil[cur];
	     preutil[cur] = preutil[gt];
	     preutil[gt] = tempd;
	     gt--;
	  }	    
       }

   while( low <= high && items[ index[low] - items[index[low]] - pos ] < 0 ) low++;
   if( low < lt - 1 )
     sortds(  pos, low, lt-1 );
   if( lt < gt && items[ index[lt] - items[index[lt]] - pos ] >= 0 )
     sortds( pos+1, lt, gt );
   if( gt + 1 < high )
     sortds( pos, gt+1, high );
}


void Dataset::merge( void )
{
   for(int i=trannum-1; i>0; i--)
     if( items[index[i]] == items[index[i-1]] )
     {
        int cur = index[i] + 1;
	int pre = index[i-1] + 1;
	while( items[cur] >= 0 && items[cur] == items[pre] )
	  {  cur++, pre++;  }
	if( items[cur] < 0 && items[pre] < 0 )
	{
	   int last = cur;
	   cur = index[i];
	   pre = index[i-1];
	   for( ; cur<last; cur++, pre++ )
	     utils[pre] += utils[cur];
	   index[i] = - 1;
	}
     }

   int len = 1; //as an end
   int num = 0;
   for(int i=0; i<trannum; i++)
     if( index[i] != - 1 )
     {
        len += ( - items[index[i]] + 1 );
        index[num++] = index[i];
     }
   trannum = num;

   memsize = len;
   int* tempi = new int[len];
   double* tempu = new double[len];
   int pos = 0;
   for(int i=0; i<trannum; i++)
   {
      int preindex = index[i];
      index[i] = pos;
      tempi[pos] = items[preindex];
      tempu[pos] = utils[preindex];
      for( pos++, preindex++; items[preindex]>=0; pos++,preindex++)
      {
	 tempi[pos] = items[preindex];
	 tempu[pos] = utils[preindex];
      }
   }
   tempi[pos] = -1;
   tempu[pos] = 0;
   delete []items;
   delete []utils;
   items = tempi;
   utils = tempu;
}


void Dataset::show( void )
{
   printf("------------------------ Dataset ------------------------\n");
   printf("itemname : ");
   for( int i=0; i<itemnum; i++ )
     printf("%d ", itemname[i]);
   printf("\n");
   printf("support : ");
   for( int i=0; i<itemnum; i++ )
     printf("%d ", support[i]);
   printf("\n");
   printf("index : ");
   for( int i=0; i<trannum; i++ )
     printf("%d ", index[i]);
   printf("\n");
   printf("Transaction:\n");
   for( int i=0; i<trannum; i++ )
   {
      printf("%d [%lf] : ", items[index[i]], utils[index[i]]);
      for( int j=index[i]+1; items[j]>=0; j++ )
	printf("%d [%lf] ", items[j], utils[j] );
      printf("\n");
   }
   printf("---------------------------------------------------------\n");
}

///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////




//////////////////////////// class Tbuffer/////////////////////////////////
///////////////////////////////////////////////////////////////////////////
Tbuffer::Tbuffer( void )
{
   items = new int[ 256 * 1024 ];
   utils = new double[ 256 * 1024 ];
   size = 256 * 1024;
   items[0] = - 1;  //as a null transaction
   pos = 1;         //start from 1
}


Tbuffer::~Tbuffer( void )
{
   delete []items;
   delete []utils;
}


void Tbuffer::append( int i, double u )
{
   items[pos] = i;
   utils[pos++] = u;
   if( ( i == -1 ) && ( ( pos + 64 * 1024 ) >= size ) )
   {
      size = 2 * size;
      int* itemp = new int[ size ];
      double* dtemp = new double[ size ];
      for( int i=0; i<pos; i++ )
      {
	 itemp[i] = items[i];
	 dtemp[i] = utils[i];
      }
      delete []items;
      delete []utils;
      items = itemp;
      utils = dtemp;
   }
}


void Tbuffer::show( void )
{
   printf("------------------------ Tbuffer ------------------------\n");
   for(int i=0; i<pos; i++)
   {
      printf("%d [%lf] ", items[i], utils[i]);
      if( items[i] < 0 )
	printf("\n");
   }
   printf("---------------------------------------------------------\n");
}
///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////




//////////////////////////// class Loader /////////////////////////////////
///////////////////////////////////////////////////////////////////////////
Loader::Loader(char* trans_file, char* price_file, double percent)
  : DS(NULL), TB(NULL)
{
   trans = fopen( trans_file, "rt" );
   if( trans == NULL )
   {
      printf("Transaction file cannot open!\n");
      exit(0);
   }
   price = fopen( price_file, "rt" );
   if( price == NULL )
   {
      printf("Price file cannot open!\n");
      fclose( trans );
      exit(0);
   }

   scan_price_file( );
   //item_* and cache are allocated, ex_util is assigned
   scan_trans_file( percent );
   //variables item_*, trans_number  and MINUTIL are assigned
   item_order = - 1; 
   init_struct( );
   create_struct( );

   delete []ex_util;
   delete []item_freq;
   delete []item_twu;
   delete []cache;
   fclose( trans );
   fclose( price );
}


Loader::~Loader( void )
{
   delete DS;
   delete TB;
}


void Loader::scan_price_file(void)
{
   fseek( price, 0, SEEK_END );
   long ch_num = ftell( price );
   cache = new char[ ch_num ];
   cache_size = ch_num;
   fseek( price, 0, SEEK_SET );
   fread( cache, ch_num, 1, price );

   item_number = 0;
   long i = 0;
   for( ; i<ch_num; i++ )
     if( cache[i]=='\n' )
       item_number++;

   ex_util = new double[ item_number ];
   int j = 0;
   double temp;

   i = 0;
   while( i<ch_num )
   {
      temp = 0;
      while( cache[i]>='0' && cache[i]<='9' )
        temp = temp * 10 + (double)(cache[i++] - '0'); //i++
      if( cache[i]=='.' )
      {
	 i++;  //skip '.'
	 double reduce = (double)0.1;
	 while( cache[i]>='0' && cache[i]<='9' )
	 {
	    temp += (double)(cache[i++] - '0') * reduce ;  //i++
	    reduce *= (double)0.1;
	 }
      }
      i++;  //skip '\n'
      ex_util[j++] = temp;  //j++
   }

   item_freq = new int[ item_number ];
   memset( item_freq, 0, item_number*sizeof(int) );
   item_twu = new double[ item_number ];
   memset( item_twu, 0, item_number*sizeof(double) );
}


void Loader::amplify_cache(void) //add 64k
{
   long len = cache_size + 64 * 1024;
   char* temp =new char[len];
   memcpy(temp, cache, cache_size);
   delete []cache;
   cache = temp;
   cache_size = len;
}


void Loader::scan_trans_file(double percent)
{
   double total_util = 0;
   int* items = new int[item_number];
   int top;

   tran_number = 0;
   long ch_num;
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans ); //!!return count
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	      amplify_cache();
	 }while( c!='\n' );
      }

      long i = 0;
      int item;
      int quantity;
      double trans_util;
      while( i<ch_num )
      {
	 trans_util = 0;
	 top = 0;
	 while( 1 )
	 {
	    item = quantity = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + (int)( cache[i++] - '0' );  //i++
	    items[top++] = item;  //top++
	    i++;  //skip ' '
	    while( cache[i]>='0' && cache[i]<='9' )
	      quantity = quantity * 10 + (int)( cache[i++] - '0' );  //i++
	    trans_util += ( ex_util[item] * (double)quantity );
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break;  }  //skip '\n'
	 }////get a transaction
	 for(int j=0; j<top; j++ )
	 {
	    item_freq[ items[j] ] ++;
	    item_twu[ items[j] ] += trans_util;
	 }
	 total_util += trans_util;
	 tran_number++; 
      }
   }while( !feof(trans) );

   delete []items;
   MINUTIL = total_util * percent ;
}


void Loader::init_struct( void )
{
   twosomeTable t(item_number);
   int total = 0;
   int i = 0;
   for( ; i<item_number; i++ )
     if( item_twu[i] >= MINUTIL )
     {
        t.append_twosome( i, item_twu[i] );
	total += item_freq[i];
     }
     else
       item_freq[i] = - 1;

   DS = new Dataset( total, tran_number, t.usedLen );
   TB = new Tbuffer;
   switch( item_order )
   {
      case - 1 : t.ascending_sort();  break;
      case 0   : t.sort();            break;
      case 1   : t.descending_sort(); break;
   }
   for( i=0; i<t.usedLen; i++ )
   {
      DS->support[i] = 0;
      DS->itemname[i] = t.table[i].name;
      item_freq[t.table[i].name] = i;
   }
}


void Loader::create_struct(void)
{
   twosomeTable t(item_number);
   long ch_num;
   fseek( trans, 0, SEEK_SET );
   double* su = new double[ DS->itemnum ];
   memset( su, 0, DS->itemnum * sizeof(double) );
   do
   {
      long half = cache_size / 2;
      ch_num = fread( cache, 1, half, trans );
      if( ch_num==half && cache[half-1]!='\n' )
      {
	 char c;
         do
	 {
	    c = (char)fgetc( trans );
	    cache[ch_num++] = c;  //ch_num++
	    if( ch_num==cache_size )
	       amplify_cache();
	 }while( c!='\n' );
      }

      int i = 0;
      int item;
      int quantity;
      while( i<ch_num )
      {
	 double twu = 0;
	 t.init( );
	 while( 1 )
	 {
	    item = 0;
	    while( cache[i]>='0' && cache[i]<='9' )
	      item = item * 10 + int( cache[i++] - '0' );  //i++
	    i++;  //skip ' '
	    if( item_freq[item]>=0 )
	    {
	       quantity = 0;
	       while( cache[i]>='0' && cache[i]<='9' )
		 quantity = quantity * 10 + int( cache[i++] - '0' );  //i++
	       double utility = ex_util[item] * quantity;
	       t.append_twosome( item_freq[item], utility );
	       twu += utility;
	    }
	    else
	      while( cache[i]>='0' && cache[i]<='9' ) i++;
	    i++;  //skip ' '
	    if( cache[i]=='\n' )  {  i++;  break; }  //skip '\n'
	 }////get a transaction
	 if( t.usedLen != 0 )
	 {
	    t.sort( );
	    DS->apptran( t, twu, 0 );
	    for(int j=0; j<t.usedLen; j++)
	    {
	       su[t.table[j].name] += twu;
	       twu -= t.table[j].value;
	    }
	 }
      }
   }while( !feof(trans) );
   //DS->show();
   DS->sortds( );
   DS->merge( );
   //printf("MINUTIL: %lf\n", MINUTIL);
   for(int i=0; i<DS->itemnum; i++)
   {
     //printf("%lf ", su[i]);
     //printf("\n");
     if( su[i] < MINUTIL )
       DS->support[i] = - DS->support[i];
   }
   //DS->show( );
   delete []su;
}
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
