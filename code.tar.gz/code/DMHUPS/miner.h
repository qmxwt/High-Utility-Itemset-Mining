#ifndef _miner
#define _miner


#include"common.h"
#include"loader.h"


class Pdb  //Projected Database
{
public:
  int     itemnum;
  int*    itemname;
  int*    support;
  double* itemutil;
  double* itemextu;
  double* itemlu;
  int     len;
  int*    item;
  double* util;
  Pdb( int num, int max );
  ~Pdb( void );
};


void print_pdb( Pdb& pdb);


class Miner
{
public:
  itemSet& IS;
  Miner( itemSet& is, int len );
  ~Miner( void );
  void DMHUPS( DB& db, Iudata& iu );
private:
  int* mapp;
  void ExtendLevel1Node( Pdb& pdb, int n, DB& db, Iudata& iu );
  void SearchforExtension( Pdb& pdb, Pdb& sub );
  int  lookahead( double up_util, int up_sup, Pdb& pdb );
  void recur_output( int pos, double preutil, Pdb& pdb );
};


#endif
