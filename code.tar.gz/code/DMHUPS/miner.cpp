#include<stdio.h>
#include<memory.h>
#include<math.h>
#include"common.h"
#include"loader.h"
#include"miner.h"


extern double MINUTIL;
extern Dataset* DS;
long explored = 0;  //explored itemsets


Pdb::Pdb( int num, int max ) : itemnum(num), len(max)
{
   itemname = new int[num];
   support  = new int[num];
   itemutil = new double[num];
   itemextu = new double[num];
   itemlu   = new double[num];
   item     = new int[max];
   util     = new double[max];
}


Pdb::~Pdb( void )
{
   delete []itemname;
   delete []support;
   delete []itemutil;
   delete []itemextu;
   delete []itemlu;
   delete []item;
   delete []util;
}


void print_pdb( Pdb& pdb )
{
   printf("Pdb .................................................\n");
   printf("itemnum  : %d\n", pdb.itemnum);
   printf("itemname : ");
   for(int i=0; i<pdb.itemnum; i++)
     printf("%d ", pdb.itemname[i]);
   printf("\n");
   printf("itemutil : ");
   for(int i=0; i<pdb.itemnum; i++)
     printf("%lf ", pdb.itemutil[i]);
   printf("\n");
   printf("itemextu : ");
   for(int i=0; i<pdb.itemnum; i++)
     printf("%lf ", pdb.itemextu[i]);
   printf("\n");
   printf("itemlu   : ");
   for(int i=0; i<pdb.itemnum; i++)
     printf("%lf ", pdb.itemlu[i]);
   printf("\n");
   for(int i=0; i<pdb.len; i++)
   {
      if( i+1 % 5 == 0 ) printf("\n");
      printf("(%d, %lf)", pdb.item[i], pdb.util[i]);
   }
   printf(".....................................................\n");
}


Miner::Miner( itemSet& is, int len ) : IS(is)
{
   mapp = new int[len];
   for(int i=0; i<len; i++)
     mapp[i] = - 1;
}


Miner::~Miner( void )
{
   delete []mapp;
   printf("Search space : %ld\n", explored);
}


void Miner::DMHUPS( DB& db, Iudata& iu )
{
   int max = 0;
   for(int i=0; i<iu.num; i++)
   {
      int cur = 0;
      for(int j=0; j<iu.list[i].len; j++)
	cur += ( iu.list[i].end[j] - iu.list[i].pos[j] + 1 );
      if ( cur > max )
	max = cur;
   }
   max = max + 1; //the Pdb ends with -1 as a bound

   explored += iu.num;
   Pdb* pdb = new Pdb( iu.num-1, max );  
   for(int i=0; i<iu.num; i++)
   {
      if( iu.list[i].util >= MINUTIL )
	IS.output( iu.list[i].itemname, iu.list[i].util );
      if( iu.list[i].extu >= MINUTIL )
      {
	 IS.push( iu.list[i].itemname );
	 ExtendLevel1Node( *pdb, i, db, iu );
	 IS.pop( );
      }
   }
   delete pdb;
}


void Miner::ExtendLevel1Node( Pdb& pdb, int n, DB& db, Iudata& iu )
{
   pdb.itemnum = iu.num - n - 1;
   for(int i=0,j=n+1; j<iu.num; i++,j++)
   {
      pdb.itemname[i] = iu.list[j].itemname;
      pdb.support[i] = 0;
      pdb.itemutil[i] = pdb.itemextu[i] = pdb.itemlu[i] = 0;
   }
   pdb.len = 0;
   int& len = pdb.len;
   if( DS == NULL )
     for(int i=0; i<iu.list[n].len; i++)
     {
        int j = iu.list[n].pos[i];
	pdb.item[len] = - 1;
	pdb.util[len++] = db.util[j];  //++
	for(j++; j<=iu.list[n].end[i]; j++,len++)
	{
	   pdb.item[len] = db.item[j] - n - 1;
	   pdb.util[len] = db.util[j];
	}
     }
   else
   {
      DS->reset( );
      for(int i=0; i<iu.list[n].len; i++)
      {
	 int j = iu.list[n].pos[i];
	 DS->appele( -1, db.util[j] );
	 for(j++; j<=iu.list[n].end[i]; j++)
	   DS->appele( db.item[j]-n-1, db.util[j] );
      }
      DS->appele( -1, 0 );
      DS->trannum--;
      //DS->sortds( );
      DS->merge( );
      for( int i=0; i<DS->trannum; i++ )
      {
	 int pos = DS->index[i];
	 pdb.item[len] = DS->items[pos];
	 pdb.util[len++] = DS->utils[pos]; //++
	 for( pos++; DS->items[pos]>=0; pos++,len++ )
	 {
	    pdb.item[len] = DS->items[pos];
	    pdb.util[len] = DS->utils[pos];
	 }
      }
   }
   pdb.item[len] = - 1; //as a bound
   //create projected database
   if( pdb.itemnum == 1 )
   {
      explored += 1;
      double utility = 0;
      for(int x=0; x<len; x++)
	utility += pdb.util[x];
      if( utility >= MINUTIL )
	IS.output( pdb.itemname[0], utility );
      return;
   }
   //OneItemExtension strategy
   int trans = 0;
   int i = 0;
   while( i < len )
   {
      trans++;
      double base = pdb.util[i];
      double tota = pdb.util[i];
      int j = i + 1;
      for( ; pdb.item[j]!=-1; j++ )
	tota += pdb.util[j];
      int last = j - 1;
      double rem = 0;
      for( j--; j>i; j-- )
      {
	 pdb.support[pdb.item[j]]++;
	 pdb.itemutil[pdb.item[j]] += ( base + pdb.util[j] );
	 pdb.itemextu[pdb.item[j]] += ( base + pdb.util[j] + rem );
	 pdb.itemlu[pdb.item[j]] += tota;
	 rem += pdb.util[j];
      }
      if( last != i )
	pdb.itemextu[pdb.item[last]] -= ( base + pdb.util[last] ); //Ex up bound
      i = last + 1;
   }
   //Calculate utility up bounds
   if( !lookahead( iu.list[n].util, iu.list[n].len, pdb ) )
   {
      explored += pdb.itemnum;
      for( i=0; i<pdb.itemnum; i++ )
	if( pdb.itemutil[i] >= MINUTIL )
	  IS.output( pdb.itemname[i], pdb.itemutil[i] );
      Pdb* sub = new Pdb( pdb.itemnum - 1, pdb.len - trans + 1 );
      SearchforExtension( pdb, *sub );
      delete sub;
   }
}


void Miner::SearchforExtension( Pdb& pdb, Pdb& sub )
{
   for(int i=0; i<pdb.itemnum; i++)
     if( pdb.itemextu[i] >= MINUTIL )
     {
	int k = 0;
	for(int j=i+1; j<pdb.itemnum; j++)
	  if( pdb.itemlu[j] >= MINUTIL )
	  {
	     sub.itemname[k] = pdb.itemname[j];
	     sub.support[k] = 0;
	     sub.itemutil[k] = sub.itemextu[k] = sub.itemlu[k] = 0;
	     mapp[j] = k;
	     k++;
	  }
	if( k == 0 ) continue;
	sub.itemnum = k;
	sub.len = 0;
	int& len = sub.len;
	if( DS == NULL )
	{  
	   k = 0;
	   while( k < pdb.len )
	   {
	      double base = pdb.util[k];
	      k++;
	      while( pdb.item[k]!=-1 && pdb.item[k]!=i )
		k++;
	      if( pdb.item[k] == i )
	      {
		 sub.item[len] = - 1;
		 sub.util[len++] = base + pdb.util[k];  //++
		 for( k++; pdb.item[k]!=-1; k++ )
		   if( mapp[pdb.item[k]] != -1  )
		   {
		      sub.item[len] = mapp[pdb.item[k]];
		      sub.util[len] = pdb.util[k];
		      len++;
		   }
		 if( sub.item[len-1] == - 1 )
		   len--; //avoid the empty transaction
	      }
	   }
	}
	else
	{
	   DS->reset( );
	   k = 0;
	   while( k < pdb.len )
	   {
	      double base = pdb.util[k];
	      k++;
	      while( pdb.item[k]!=-1 && pdb.item[k]!=i )
		k++;
	      if( pdb.item[k] == i )
	      {
		 DS->appele( -1, base + pdb.util[k] );
		 int flag = 0;
		 for( k++; pdb.item[k]!=-1; k++ )
		   if( mapp[pdb.item[k]] != -1 )
		   {  
		      DS->appele( mapp[pdb.item[k]], pdb.util[k] );
		      flag = 1;
		   }
		 if( flag != 1 )
		 {
		    DS->trannum--;
		    DS->mempos--;
		 }  
	      }
	   }//end while
	   DS->appele( -1, 0 );
	   DS->trannum--;
	   DS->sortds( );
	   DS->merge( );
	   for( int x=0; x<DS->trannum; x++ )
	   {
	      int pos = DS->index[x];
	      sub.item[len] = DS->items[pos];
	      sub.util[len++] = DS->utils[pos];
	      for( pos++; DS->items[pos]>=0; pos++,len++ )
	      {
		 sub.item[len] = DS->items[pos];
		 sub.util[len] = DS->utils[pos];
	      }
	   }
	}	
	sub.item[len] = - 1;//as a bound
	for(int j=i+1; j<pdb.itemnum; j++)
	  if( pdb.itemlu[j] >= MINUTIL )
	    mapp[j] =  -1 ;
	//create projected database
	if( sub.itemnum == 1 )
	{
	   explored += 1;
	   double utility = 0;
	   for(int x=0; x<len; x++)
	     utility += sub.util[x];
	   if( utility >= MINUTIL )
	   {
	      IS.push( pdb.itemname[i] );
	      IS.output( sub.itemname[0], utility );
	      IS.pop( );
	   }
	   continue;
	}//OneItemExtension strategy
	int trans = 0;
	k = 0;
	while( k < len )
	{
	   trans++;
	   double base = sub.util[k];
	   double tota = sub.util[k];
	   int j = k + 1;
	   for( ; sub.item[j]!=-1; j++)
	     tota += sub.util[j];
	   int last = j - 1;
	   double rem = 0;
	   for( j--; j>k; j-- )
	   {
	      sub.support[sub.item[j]]++;
	      sub.itemutil[sub.item[j]] += ( base + sub.util[j] );
	      sub.itemextu[sub.item[j]] += ( base + sub.util[j] + rem );
	      sub.itemlu[sub.item[j]] += tota;
	      rem += sub.util[j];
	   }
	   if( last != k )
	     sub.itemextu[sub.item[last]] -= ( base + sub.util[last] );
	   k = last + 1;
	}
	//Calculate utility up bounds
	IS.push( pdb.itemname[i] );
	if( ! lookahead( pdb.itemutil[i], pdb.support[i], sub ) )
	{
	   explored += sub.itemnum;
	   for( int j=0; j<sub.itemnum; j++ )
	     if( sub.itemutil[j] >= MINUTIL )
	       IS.output( sub.itemname[j], sub.itemutil[j] );
	   Pdb* subsub = new Pdb( sub.itemnum - 1, sub.len - trans + 1 );
	   SearchforExtension( sub, *subsub );
	   delete subsub;
	}
	IS.pop( );
     }
}


int Miner::lookahead( double up_util, int up_sup, Pdb& pdb )
{
   int Ahead = 1; //suppose Ahead is OK
   double sumUtil = up_util;
   double minUtil = pdb.itemutil[0] - up_util;

   for(int i=0; i<pdb.itemnum; i++)
   {
      if( pdb.support[i] != up_sup )
	return 0;
      if( pdb.itemutil[i] < MINUTIL )
	Ahead = 0;
      double temp = pdb.itemutil[i] - up_util;
      sumUtil += temp;
      if( minUtil > temp ) minUtil = temp;
   }
   if( Ahead )
   {
      explored += ( (long)pow(2,pdb.itemnum) - 1 );
      for(int i=0; i<pdb.itemnum; i++)
	pdb.itemutil[i] -= up_util;
      for(int i=0; i<pdb.itemnum; i++)
      {
	 double utility = up_util + pdb.itemutil[i];
	 IS.output( pdb.itemname[i], utility );
	 IS.push( pdb.itemname[i] );
	 recur_output( i+1, utility, pdb );
	 IS.pop( );
      }
      return 1;
   }
   if( sumUtil >= MINUTIL && ( sumUtil - minUtil ) < MINUTIL )
   {
      explored += 1;
      for(int i=0; i<pdb.itemnum-1; i++)
	IS.push( pdb.itemname[i] );
      IS.output( pdb.itemname[pdb.itemnum-1], sumUtil );
      for(int i=0; i<pdb.itemnum-1; i++)
	IS.pop( );
      return 1;
   }
   return 0;
}


void Miner::recur_output( int pos, double preutil, Pdb& pdb )
{
   if( pos == pdb.itemnum )
     return;

   recur_output( pos+1, preutil, pdb );
   double utility = preutil + pdb.itemutil[pos];
   IS.output( pdb.itemname[pos], utility );
   IS.push( pdb.itemname[pos] );
   recur_output( pos+1, utility, pdb );
   IS.pop( );
}



