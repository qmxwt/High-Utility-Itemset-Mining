#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include"loader.h"
#include"miner.h"


extern long peak;
extern int ITERDEPTH;
extern Machine* m;
extern int ALPHA;
extern long explored; 

int main(int argc, char* argv[])
{
   struct timeval t1, t2;
   long double interval;
   gettimeofday(&t1, NULL);

   if( argc!=4 && argc!=5 )
   {
      printf("Usage :\n");
      printf("  Rex  trans_file  price_file  min_util  [output_filename]\n");
      exit(0);
   }

   Loader L( argv[1], argv[2], (double)(atof(argv[3])) );
   char* outfp = NULL;
   if( argc==5 )  outfp = argv[4];
   itemSet IS( ITERDEPTH, outfp );
   m = new Machine( ALPHA, IS );
   Miner M(  *L.caul, IS );
   M.mine( );
   IS.show();
   delete m;

   gettimeofday(&t2, NULL);
   interval = ((t2.tv_sec - t1.tv_sec) * 1000) + ((t2.tv_usec - t1.tv_usec) / 1000);
   interval = interval / 1000;
   printf("Mining time (second) : %Lf\n", interval);

   long double memusage = peak / (long double) (1024 * 1024 );
   printf("Peak memory (MB) : %Lf\n", memusage);
   printf("Search space : %ld\n", explored);

   return 0;
}
