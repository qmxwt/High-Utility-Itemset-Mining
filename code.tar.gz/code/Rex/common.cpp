#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include"common.h"


double    MINUTIL;
int       ITERDEPTH;
Machine*  m = NULL;
int       ALPHA = 16;  //The size of item machine
extern long  explored;


/////////////////////rewrite new and delete//////////////////////////////////////
long current = 0;
long peak = 0;

void* operator new( size_t sz )
{
   sz = sz + 8;
   void* m = malloc( sz );
   if( !m )
   {
      printf("Out of memory!\n");
      exit( 0 );
   }
   long* x = (long *)m;
   *x = sz;
   x = x + 1;

   current += sz;
   if( peak < current )
     peak = current;

   return (void *)x;
}

void operator delete( void* m )
{
   long* x = (long *)m;
   x = x - 1;
   current -= *x;
   free( (void *)x );
}

void* operator new[]( size_t sz )
{
   sz = sz + 8;
   void* m = malloc( sz );
   if( !m )
   {
      printf("Out of memory!\n");
      exit( 0 );
   }
   long* x = (long *)m;
   *x = sz;
   x = x + 1;

   current += sz;
   if( peak < current )
     peak = current;

   return (void *)x;
}

void operator delete[]( void* m )
{
   long* x = (long *)m;
   x = x - 1;
   current -= *x;
   free( (void *)x );
}
//////////////////////////////////////////////////////////////////////////




//////////////////////// Class twosomeTable /////////////////////////////
void twosomeTable::descending_sort(int low, int high)
{
   int i = low;
   int j = high;
   key_twosome = table[i];
   key_value = key_twosome.value;

   while( i!=j )
   {
      while( i<j && key_value>=table[j].value )
        j--;
      if( i<j )
        table[i++] = table[j];
      while( i<j && table[i].value>=key_value )
        i++;
      if( i<j )
        table[j--] = table[i];
   }

   table[i] = key_twosome;
   if( low < (i-1) )
     descending_sort( low, i-1 );
   if( (i+1) < high )
     descending_sort( i+1, high );
}

void twosomeTable::ascending_sort(int low, int high)
{
   int i = low;
   int j = high;
   key_twosome = table[i];
   key_value = key_twosome.value;

   while( i!=j )
   {
      while( i<j && key_value<=table[j].value )
        j--;
      if( i<j )
        table[i++] = table[j];
      while( i<j && table[i].value<=key_value )
        i++;
      if( i<j )
        table[j--] = table[i];
   }

   table[i] = key_twosome;
   if( low < (i-1) )
     ascending_sort( low, i-1 );
   if( (i+1) < high )
     ascending_sort( i+1, high );
}

void twosomeTable::sort(int low, int high)
{
   int i = low;
   int j = high;
   key_twosome = table[i];
   key_name = key_twosome.name;

   while( i!=j )
   {
      while( i<j && key_name<=table[j].name )
        j--;
      if( i<j )
        table[i++] = table[j];
      while( i<j && table[i].name<=key_name )
        i++;
      if( i<j )
        table[j--] = table[i];
   }

   table[i] = key_twosome;
   if( low < (i-1) )
     sort( low, i-1 );
   if( (i+1) < high )
     sort( i+1, high );
}
//////////////////////////////////////////////////////////////////////////




int    ACCURACY = 1000000; 
/////////////////////////// Class itemSet ////////////////////////////////
itemSet::itemSet(int len, char* filename)
{
   items = new int[len];
   top = 0;
   results = new long[len];
   memset( results, 0, len * sizeof(long) );
   upbound = len;
   if( filename!=NULL )
   {
      outflag = 1;
      outfile = fopen( filename, "w" );
      if( outfile==NULL )
      {
	 printf("Cannot output to %s\n", filename);
	 exit(0);
      }
   }
   else
     outflag = 0;

   preitems[0] = ' ';
   pretop = 1;
   buf = new char[ 64 * 1024 ];
   bound = 4 * 1024;
   current = 64 * 1024 - 1 ;
}

itemSet::~itemSet(void)
{
   delete []items;
   delete []results;
   if( outflag )
   {
     if( current != 64 * 1024 - 1 )
       fwrite( buf+current+1, 64*1024-current-1, 1, outfile );
     fclose( outfile );
   }
   delete []buf;
}

void itemSet::show(void)
{
   int i = 0;
   long total = 0;
   for( ; i<upbound; i++ )
     if( results[i]!=0 )
     {
        printf( "%ld\n", results[i] );
	total += results[i];
     }
   printf("Total number of itemsets : %ld\n", total);
}


void itemSet::output( int item, double utility )
{
   results[top]++;
   if( outflag )
   {
      buf[current--] = '\n';
      buf[current--] = ')';
      int intpart = (int)utility;
      int decpart = (int)((utility - intpart) * ACCURACY);
      do
      {
	 buf[current--] = (char)(decpart % 10 + 48);
	 decpart = decpart / 10;
      }while( decpart != 0 );
      buf[current--] = '.';
      do
      {
	 buf[current--] = (char)(intpart % 10 + 48);
	 intpart = intpart / 10;
      }while( intpart != 0 );
      buf[current--] = '(';
      buf[current--] = ' ';
      do
      {
	 buf[current--] = (char)(item % 10 + 48);
	 item = item / 10;
      }while( item != 0 );
      for(int i=pretop-1; i>0; i--)
	buf[current--] = preitems[i];
      if( current <= bound )
      {
	 fwrite( buf+current+1, 64*1024-current-1, 1, outfile );
	 current = 64 * 1024 - 1;
      }
   }
}


void itemSet::output( double utility )
{
   results[top-1]++;
   if( outflag )
   {
      buf[current--] = '\n';
      buf[current--] = ')';
      int intpart = (int)utility;
      int decpart = (int)((utility - intpart) * ACCURACY);
      do
      {
	 buf[current--] = (char)(decpart % 10 + 48);
	 decpart = decpart / 10;
      }while( decpart != 0 );
      buf[current--] = '.';
      do
      {
	 buf[current--] = (char)(intpart % 10 + 48);
	 intpart = intpart / 10;
      }while( intpart != 0 );
      buf[current--] = '(';
      for(int i=pretop-1; i>0; i--)
	buf[current--] = preitems[i];
      if( current <= bound )
      {
	 fwrite( buf+current+1, 64*1024-current-1, 1, outfile );
	 current = 64 * 1024 - 1;
      }
   }
}
//////////////////////////////////////////////////////////////////////////




/////////////////////////// Class Machine ////////////////////////////////
Machine::Machine( int N, itemSet& is ) : IS( is )
{
   int T = (int)pow( 2, N );
   utilvector = new double*[ T ];
   preutil = new double[ T ];
   indexlist = new int[ T ];

   itemname = new int[ N ];
   cardinal = new int[ N ];
   listend = new int[ N ];  
   utility = new double[ N ];
   remain = new double[ N ];
   twu = new double[ N ];
   utils = new double[ N ];
   items = new int[ N ];
   top =0;

   indexlist[0] = 0;
   int power = 0;
   int interval = 1;
   for(int i=1; i<T; i++)
   {
      if( i == (int)pow(2, power) )
      {
	 interval = i;
	 power = power + 1;
      }
      indexlist[i] = indexlist[i-interval] + 1;  
   }
   int acculumate = 0;
   for(int i=1; i<T; i++)
   {
      int current = indexlist[i];
      indexlist[i] = acculumate;
      acculumate += current;
      
   }
   
   double* temp = new double[ N * T / 2 ];
   for(int i=0; i<T; i++)
   {
      utilvector[i] = temp + indexlist[i];
      preutil[i] = - 1;
   }
   for(int i=0; i<N; i++)
     cardinal[i] = listend[i] = (int)pow(2, i);

   memset( utility, 0, N * sizeof(double) );
   memset( remain, 0, N * sizeof(double) );
   memset( twu, 0, N * sizeof(double) );

   running_time = 0;
}


Machine::~Machine( void )
{
   delete []utilvector[0];
   delete []utilvector;
   delete []preutil;
   delete []indexlist;
   delete []itemname;
   delete []cardinal;
   delete []listend;
   delete []utility;
   delete []remain;
   delete []twu;
   delete []utils;
   delete []items;
   printf("Machine running time (second) : %Lf\n", running_time);
}


void Machine::init( int num, int* name )
{
   gettimeofday(&t1, NULL);   
   for(int i=0; i<num; i++)
   {
      while( listend[i] > cardinal[i] )
      {
	 listend[i]--;
	 preutil[indexlist[listend[i]]] = - 1;
      }     
      itemname[i] = name[i];
      utility[i] = remain[i] = twu[i] = 0;
   }
}


void Machine::insert( twosomeTable& t, double pre )
{
   double rem = 0;
   double total = pre; 
   int pos = 0;
   for(int i=0; i<t.usedLen; i++)
   {
      utility[t.table[i].name] += ( pre + t.table[i].value );
      total += t.table[i].value;
      remain[t.table[i].name] += rem;
      rem += t.table[i].value;
      pos = pos + (int)pow( 2, t.table[i].name ); 
   }
 
   if( preutil[pos] < 0 )
   {
      for(int i=0; i<t.usedLen; i++)
      {
	 utilvector[pos][i] = t.table[i].value;
	 twu[t.table[i].name] += total;
      }
      preutil[pos] = pre;
      indexlist[listend[t.table[t.usedLen-1].name]] = pos;
      listend[t.table[t.usedLen-1].name]++;
   }  
   else
   {
      for(int i=0; i<t.usedLen; i++)
      {
	  utilvector[pos][i] += t.table[i].value;
	  twu[t.table[i].name] += total;	  
      }
      preutil[pos] += pre;
   }
}


void Machine::merge( int item, int pos, double* u, int top, double pre )
{
   if( preutil[pos] < 0 )
   {
      preutil[pos] = pre;
      for( int i=0; i<top; i++ )
	utilvector[pos][i] = u[i];
      indexlist[listend[item]] = pos;
      listend[item]++;
   }
   else
   {
      preutil[pos] += pre;
      for( int i=0; i<top; i++ )
	utilvector[pos][i] += u[i];
   }
}


void Machine::run( int num )
{
   explored += num;
   if( num == 0 ) return;
   if( propagate_and_eliminate( num ) )
   for( int i=0; i<num; i++ )
   {
      if( utility[i] >= MINUTIL )
	IS.output( itemname[i], utility[i] );
      if( utility[i] + remain[i] >= MINUTIL )
      {
	 IS.push( itemname[i] );
	 clear( i );
	 project( i );
	 run( i );
	 IS.pop( );
      }
   }
}


int Machine::propagate_and_eliminate( int num )
{
   int valid = 0;
   for( int i=0; i<num; i++ )
     if( twu[i] >= MINUTIL )
       valid += cardinal[i];
   
   if( valid == 0 ) return 0;

   for( int i=num-1; i>0; i-- )
   {
      int mask = ( ~cardinal[i] ) & valid;
      for( int j=cardinal[i]; j<listend[i]; j++ )
      {
	 int pos = indexlist[j];
	 int cur = pos & mask;
	 if( cur == 0 ) continue;
	 int top = 0;
	 int v = - 1;
	 int item = - 1;
	 for( int k=0; k<i; k++ )
	   if( (pos&cardinal[k]) != 0 )
	   {
	      v++;
	      if( (cur&cardinal[k]) != 0 )
	      {
		 utils[top] = utilvector[pos][v];
		 top++;
		 item = k;
	      }
	   }
	 if( item != -1 )
	   merge( item, cur, utils, top, preutil[pos] );
      }
   }
   return 1;
}


void Machine::project( int x )
{
   for( int i=0; i<x; i++ )
     utility[i] = remain[i] = twu[i] = 0;

   for( int i=cardinal[x]; i<listend[x]; i++ )
   {
      int pos = indexlist[i];
      int cur = pos - cardinal[x];
      if( cur == 0 ) continue;
      double total = preutil[pos];
      top = 0;
      for( int j=0; j<x; j++ )
	if( (cardinal[j]&pos) != 0 )
	{
	   items[top] = j;
	   utilvector[cur][top] = utilvector[pos][top];
	   total += utilvector[pos][top];
	   top++;
	}
      total += utilvector[pos][top];
      preutil[cur] = preutil[pos] + utilvector[pos][top];
      int item = items[top-1];
      indexlist[listend[item]] = cur;
      listend[item]++;
      double rem = 0;
      for( int j=0; j<top; j++ )
      {
	 item = items[j];
	 utility[item] += ( preutil[cur] + utilvector[cur][j] );
	 twu[item] += total;
	 remain[item] += rem;
	 rem += utilvector[cur][j];
      }
   }   
}


void Machine::clear( int num )
{
   for( int i=0; i<num; i++ )
     while( listend[i] > cardinal[i] )
     {
        listend[i]--;
	preutil[indexlist[listend[i]]] = - 1;
     }
}


void Machine::close( void )
{
   long double interval;
   gettimeofday(&t2, NULL);
   interval = ((t2.tv_sec - t1.tv_sec) * 1000) + ((t2.tv_usec - t1.tv_usec) / 1000);
   interval = interval / 1000;
   running_time = running_time + interval;
}

//////////////////////////////////////////////////////////////////////////
